import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))) if os.path.basename(os.path.dirname(os.path.abspath(__file__))) in ('generators','legacy') else os.path.dirname(os.path.abspath(__file__)))
from paths import SRC, PAGES, SITE
import re
CODE='''// Digital thermometer: LM35 module + 2 × SC39-11SURKWA (same wiring as the dice, project 12)
const byte SEG[8]   = {2, 3, 4, 5, 6, 7, 8, 9};  // a b c d e f g dp (each via 330 Ω)
const byte DIGIT[2] = {10, 11};                  // → 1 kΩ → BC547 base, collector = display COM
const byte SENSOR   = A0;                        // LM35 module "S" pin: 10 mV per °C
const byte FONT[11] = {0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F, 0x00}; // 0–9, 10 = blank
byte value[2] = {10, 0};

void showDigit(byte d, byte n) {
  for (byte s = 0; s < 8; s++) digitalWrite(SEG[s], bitRead(FONT[n], s));
  digitalWrite(DIGIT[d], HIGH);   // transistor ON → this display lights
  delay(4);
  digitalWrite(DIGIT[d], LOW);    // OFF before changing the segments
}

void refresh(unsigned long ms) {  // keep both displays lit for ms milliseconds
  unsigned long start = millis();
  while (millis() - start < ms) { showDigit(0, value[0]); showDigit(1, value[1]); }
}

float readTemp() {
  long sum = 0;
  for (int i = 0; i < 20; i++) sum += analogRead(SENSOR);  // average 20 readings: steadier
  float volts = sum / 20.0 * 1.1 / 1023.0;                 // 1.1 V internal reference
  return volts * 100.0;                                    // 10 mV per °C → °C
}

void setup() {
  for (byte s = 0; s < 8; s++) pinMode(SEG[s], OUTPUT);
  for (byte d = 0; d < 2; d++) pinMode(DIGIT[d], OUTPUT);
  analogReference(INTERNAL);      // measure 0–1.1 V instead of 0–5 V: 0.1 °C steps
  analogRead(SENSOR);             // the first reading after switching is junk
}

void loop() {
  static unsigned long last = 0;
  if (millis() - last > 500) {    // a new measurement twice per second
    last = millis();
    int t = constrain((int)(readTemp() + 0.5), 0, 99);   // round to whole degrees
    value[0] = (t < 10) ? 10 : t / 10;                    // tens (blank if 0)
    value[1] = t % 10;                                     // units
  }
  refresh(20);
}'''
CODE=CODE.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
steps=[
 "USB <b>unplugged</b>. Link the − rails (top ↔ bottom). Arduino <b>GND</b> → bottom <b>−</b> rail.",
 "Display 1 (tens) across the gap, decimal point bottom-right, columns <b>20–24</b> (pins 1–5 bottom row left→right, pins 10–6 top row left→right). Display 2 (units) the same way in columns <b>30–34</b>.",
 "Link the matching segment pins of the two displays: top <b>a20→a30, b21→b31, a23→a33, b24→b34</b>; bottom <b>j20→j30, i21→i31, j23→j33, i24→i34</b>. <b>Not</b> columns 22/32 (COM).",
 "Top-half segments (a, b, f, g): Arduino wire → row a, <b>330 Ω</b> in row b, jumper from row c to the display pin. D2→<b>a2</b>, 330 Ω <b>b2→b5</b>, <b>c5→d23</b> (a). D3→<b>a6</b>, <b>b6→b9</b>, <b>c9→d24</b> (b). D7→<b>a10</b>, <b>b10→b13</b>, <b>c13→d21</b> (f). D8→<b>a14</b>, <b>b14→b17</b>, <b>c17→d20</b> (g).",
 "Bottom-half segments (e, d, c, dp): D6→<b>j2</b>, 330 Ω <b>i2→i5</b>, <b>h5→h20</b> (e). D5→<b>j6</b>, <b>i6→i9</b>, <b>h9→h21</b> (d). D4→<b>j10</b>, <b>i10→i13</b>, <b>h13→h23</b> (c). D9→<b>j14</b>, <b>i14→i17</b>, <b>h17→h24</b> (dp).",
 "Transistors (flat side facing you, C B E): #1 in <b>c45 c46 c47</b>, #2 in <b>c50 c51 c52</b>. Emitters: <b>a47</b> and <b>a52</b> → top − rail.",
 "COM: <b>i22</b> (display 1 pin 3) → <b>e45</b> (collector #1). <b>i32</b> (display 2 pin 3) → <b>e50</b> (collector #2).",
 "Bases: Arduino <b>D10</b> → <b>a40</b>, 1 kΩ <b>b40→b46</b>. <b>D11</b> → <b>a42</b>, 1 kΩ <b>d42→d51</b>.",
 "The sensor: Arduino <b>5V</b> → top <b>+</b> rail (tp55). LM35 module (3 female-male jumpers): <b>Vcc</b> → top + rail, <b>Gnd</b> → top − rail, <b>S</b> → <b>a56</b>. Arduino <b>A0</b> → <b>b56</b>. Plug in USB, upload the code: the room temperature appears. Pinch the sensor between your fingers and watch it climb!"]
how=[
 "The <b>LM35</b> is a chip that gives a voltage proportional to temperature: exactly <b>10 mV per °C</b>. At 23 °C its S pin sits at 0.23 V. The module just puts it on a small board with 3 pins.",
 "The Arduino's <b>A0</b> pin contains an <b>analog-to-digital converter</b> (ADC): it compares the voltage with a reference and gives a number from 0 to 1023. With the normal 5 V reference, one step is 4.9 mV, so ~0.5 °C. The code switches to the chip's internal <b>1.1 V reference</b>: one step is 1.07 mV, about <b>0.1 °C</b>, and 0–110 °C still fits.",
 "<b>Water analogy:</b> the ADC is a measuring jug with 1024 marks. A 5 V jug for a few drops of water (0.23 V) is hard to read; the small 1.1 V jug has its marks much closer together.",
 "Then it's the same as the dice: 20 readings are averaged (less jitter), converted to °C, rounded, split into tens and units, and shown on the two displays with <b>multiplexing</b> (each one lit 4 ms at a time, too fast for your eye)."]
var=[("Show tenths: \"23.5\" style with the decimal point","Show <code>t/10</code> on display 1 <b>with dp</b> (bit 7 of FONT) and the first decimal on display 2: 0.0–9.9 … or keep 2 digits and switch to tenths below 10 °C."),
 ("Remove <code>analogReference(INTERNAL)</code>","Back to the 5 V reference: the reading jumps in ~0.5 °C steps and the display flickers between two values."),
 ("Average 1 reading instead of 20","The last digit jitters: real signals are noisy."),
 ("Add the passive buzzer on D12 (via 100 Ω)","An alarm: <code>if (t &gt; 30) tone(12, 2000, 100);</code> beeps when it gets hot."),
 ("Fahrenheit","<code>f = c * 9 / 5 + 32</code>: shows 73 for 23 °C."),
 ("The bare LM35DZ chip instead of the module","Same thing for €2.50: flat side facing you, pins +Vs, Vout, GND (left to right).")]
sec=f'''
<section id="p20">
  <h2><span class="num">20</span>Digital thermometer (LM35 + Arduino)</h2>
  <p><span class="qtopic">Real parts</span> The room temperature in big red digits. An <b>LM35 temperature module</b> gives 10 mV per °C, the Arduino measures it and shows it on the two <b>SC39-11SURKWA</b> displays. The whole display side is the same wiring as the <a class="navlink" href="#p12">digital dice</a>: only the sensor and the code change.</p>
  <div class="controls"><button id="thHot" style="font-size:1.05rem">🤏 Hold to warm the sensor</button><label class="slider"><input type="checkbox" id="thRef" checked> 1.1 V reference</label><label class="slider"><input type="checkbox" id="thAvg" checked> average 20 readings</label></div>
  <canvas id="m20" width="800" height="300"></canvas>
  <p class="hint">Hold the button to "pinch" the sensor and watch the chain: temperature → LM35 voltage → ADC number → °C → digits. Untick the two boxes to see why the code uses the 1.1 V reference and averaging.</p>
  <h3>Wiring summary</h3>
  <table>
    <tr><td>Part</td><td>Goes to</td></tr>
    <tr><td>Displays, 8 × 330 Ω, 2 × BC547, 2 × 1 kΩ</td><td>Exactly as in <a class="navlink" href="#p12">project 12</a> (D2–D9 segments, D10/D11 digit transistors). No button this time.</td></tr>
    <tr><td>LM35 module <b>Vcc</b> / <b>Gnd</b></td><td>Arduino <b>5V</b> / <b>GND</b> (through the breadboard rails).</td></tr>
    <tr><td>LM35 module <b>S</b></td><td>Arduino <b>A0</b>.</td></tr>
  </table>
  <h3>Arduino code</h3>
  <pre style="background:#0b1220;border:1px solid var(--line);border-radius:10px;padding:14px;overflow:auto;font-size:.88rem;line-height:1.45"><code>{CODE}</code></pre>
  <div style="margin-top:12px"><h3 style="margin-top:0">🧰 You need</h3><ul><li>LM35 temperature module ST039 (Gotronic 35208)</li><li>Arduino Uno or compatible (e.g. Joy-It ONE-C) + USB cable</li><li>2 × SC39-11SURKWA (Gotronic 03099)</li><li>8 × 330 Ω, 2 × 1 kΩ, 2 × BC547B</li><li>Breadboard + jumper wires (3 female-male for the module)</li></ul></div>
  <h3>💡 How it works</h3>
  <div class="howbox">{''.join(f'<p>{p}</p>' for p in how)}</div>
  <h3>🏁 Final breadboard setup</h3>
  <p class="hint" style="margin-top:-6px">This is what your board should look like when it's finished (and powered). Compare with it at the end.</p>
  <canvas id="bbF_p20" class="bbc" width="800" height="440"></canvas>
  <h3 class="wtitle">🔌 Step-by-step wiring <span class="wprog"></span> <button class="wreset">↺ reset</button></h3>
  <p class="hint" style="margin-top:-6px">Follow the steps in order and tick each one. Wire with the USB <b>unplugged</b>, and plug it in <b>last</b>. Steps 1–8 are the same as the dice: if it's still on your board, jump to step 9. Column and hole numbers (a–j) follow the <a class="navlink" href="#cintro">breadboard map</a>.</p>
  <div class="bblive"><div class="bbcap">🧩 Your breadboard so far: parts appear as you tick the steps, and the <span style="color:#f59e0b">glowing outline</span> shows where the next step goes.</div><canvas id="bbS_p20" class="bbc" width="800" height="440"></canvas></div>
  <ol class="wsteps">{''.join(f'<li><label><input type="checkbox"><span>{t}</span></label></li>' for t in steps)}</ol>
  <h3>🧪 Variants to try</h3>
  <table>{''.join(f'<tr><td>{a}</td><td>{b}</td></tr>' for a,b in var)}</table>
</section>'''
s=open('circuits_body.html').read()
if '<section id="p20">' in s:
    a=s.index('<section id="p20">');b=s.index('</section>',a)+10;s=s[:a]+s[b:]
k=s.index('\n<section id="rl1">');s=s[:k]+sec+s[k:]
if 'data-cl="p20"' not in s:
    an='<a href="#p19" data-cl="p19"><span class="n">19</span>Counter 00–99</a>'
    assert an in s; s=s.replace(an,an+'<a href="#p20" data-cl="p20"><span class="n">20</span>Thermometer</a>')
    an2='<a class="navlink" href="#p19">19 Counter 00–99</a>'
    assert an2 in s; s=s.replace(an2,an2+' · <a class="navlink" href="#p20">20 Thermometer</a>')
s=s.replace('19 breadboard projects','20 breadboard projects')
open('circuits_body.html','w').write(s)
c=open('circuits.js').read()
js='''
// ===== p20 thermometer layout (built from p12) =====
BBL.p20={power:9,parts:BBL.p12.parts.filter(p=>p.s!==9).map(p=>p.t==='box'?Object.assign({},p,{w:280,pins:p.pins.filter(q=>q.n!=='D12').concat([{n:'5V',dx:244,dy:72,to:'tp55',s:9,c:W_R},{n:'A0',dx:264,dy:72,to:'b56',s:9,c:W_Y}])}):p.t==='seg7'?Object.assign({},p,{show:p.col===20?'abged':'abgcd'}):p).concat([
  {s:9,t:'box',at:[600,10],w:160,h:50,lab:'🌡️ LM35 module',col:'#9a3412',ly:22,pins:[{n:'S',dx:30,dy:50,to:'a56',c:W_Y},{n:'Vcc',dx:80,dy:50,to:'tp57',c:W_R},{n:'Gnd',dx:130,dy:50,to:'tn58',c:W_B}]}])};
'''
c=re.sub(r'\n// ===== p20 thermometer layout \(built from p12\) =====\n.*?\]\)\};\n','\n',c,flags=re.S)
c=c.replace('// wire up final + live canvases',js+'// wire up final + live canvases',1)
open('circuits.js','w').write(c)
print('ok')
