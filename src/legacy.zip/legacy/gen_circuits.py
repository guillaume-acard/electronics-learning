import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))) if os.path.basename(os.path.dirname(os.path.abspath(__file__))) in ('generators','legacy') else os.path.dirname(os.path.abspath(__file__)))
from paths import SRC, PAGES, SITE
P=[
 ('p1','1','Resistor','resistor','LED brightness with different resistors',
  'See how the resistor sets the current, and so the brightness.',
  ['9 V battery + clip','1 red LED (5 mm)','Resistors: 220 Ω, 470 Ω, 1 kΩ, 10 kΩ','Breadboard + jumper wires'],
  ['Battery + → resistor → LED long leg (anode).','LED short leg → battery −.'],
  [('Swap 220 Ω → 470 Ω → 1 kΩ → 10 kΩ','The LED gets dimmer as R grows (I = 7 V ÷ R).'),('Put two 1 kΩ in series','Same as 2 kΩ: dimmer.'),('Put two 1 kΩ side by side (parallel)','Same as 500 Ω: brighter.'),('Turn the LED round','Nothing: it\'s a one-way valve.')]),
 ('p2','2','Capacitor','capacitor','LED that fades out slowly',
  'Watch a capacitor act as an energy reserve.',
  ['9 V battery','Push button','Electrolytic capacitors: 100 µF, 470 µF, 1000 µF (16 V or more)','470 Ω resistor, red LED'],
  ['Battery + → button → a node.','From the node: capacitor + to the node, capacitor − (stripe) to battery −.','From the node: 470 Ω → LED → battery −.'],
  [('100 µF vs 1000 µF','A bigger capacitor gives a longer fade (more stored charge).'),('220 Ω instead of 470 Ω','Brighter, but a shorter fade (it empties faster).'),('Remove the capacitor','The LED snaps off instantly.'),('Measure the capacitor with a multimeter while fading','You can watch the voltage drop.')]),
 ('p3','3','Diode','diode','Polarity tester (which way is +?)',
  'Two LEDs back to back show which way the current flows.',
  ['9 V battery','1 red + 1 green LED','1 kΩ resistor','2 test wires'],
  ['Put the LEDs in parallel but <b>opposite ways</b> (red long leg with green short leg).','Add the 1 kΩ in series with the pair.','Touch the two wires to a battery.'],
  [('Swap the battery wires','The other colour lights: each LED only conducts one way.'),('Add a 1N4007 diode in series','Only one colour can ever light: the diode blocks the other direction.'),('Measure across a lit LED','About 2 V (red) or 2–3 V (green): the forward voltage.')]),
 ('p4','4','LED','led','Mini traffic light',
  'Three colours, each with its own resistor (and why).',
  ['9 V battery (or 5 V USB)','Red, yellow, green LEDs','3 × 470 Ω resistors','3 push buttons'],
  ['Each LED gets its <b>own</b> 470 Ω resistor and its own button to +.','All LED short legs go to −.'],
  [('Press all 3 at once','All three light equally.'),('Try ONE shared resistor for all 3','Uneven brightness: one LED hogs the current.'),('Swap red for blue','A blue LED needs ~3 V, so it\'s a bit dimmer with the same resistor.')]),
 ('p5','5','Transistor','transistor','Touch switch (skin turns on an LED)',
  'Two transistors amplify the tiny current through your finger ~10,000×.',
  ['9 V battery','2 × BC547 (NPN)','1 kΩ + 470 Ω resistors','LED, 2 bare wires as touch pads'],
  ['Transistor 1 emitter → transistor 2 base (a "Darlington pair").','Both collectors → LED → 470 Ω → +9 V.','Transistor 2 emitter → −.','Pad A → +9 V via 1 kΩ, pad B → transistor 1 base.'],
  [('Touch both pads with one finger','The LED lights: your skin lets a tiny current flow.'),('Use only one transistor','Dim or nothing: not enough gain.'),('Wet finger vs dry finger','Wet skin conducts better, so it\'s brighter.')]),
 ('p6','6','Inductor','inductor','The coil kick-back (inductive spike)',
  'Make a coil\'s "water hammer" visible with an LED.',
  ['9 V battery','A relay (use its coil) or a small 10–100 mH inductor','Push button','1 LED (no resistor needed here)','1N4007 diode (for the variant)'],
  ['Battery → button → coil → battery −.','Put the LED across the coil <b>backwards</b> (long leg towards the battery −).'],
  [('Press, then release the button','The LED flashes on release: the spike reverses direction and lights it.'),('Replace the LED with a 1N4007 diode (same orientation)','No flash: the diode absorbs the spike safely (that\'s a flyback diode).'),('Use a coil with more turns','A bigger kick.')]),
 ('p7','7','Relay','relay','Relay clicker with two lamps',
  'A small button controls a separate circuit through a relay.',
  ['5 V relay (or a relay module)','BC547 + 1 kΩ + 1N4007','Push button','2 LEDs + 2 × 470 Ω (as "lamps") + separate 9 V battery'],
  ['Button → 1 kΩ → BC547 base. Relay coil between +5 V and the collector, with the diode across the coil (stripe to +).','On the switch side: COM → 9 V +. NC → red LED + resistor. NO → green LED + resistor.'],
  [('Press the button','Click: red goes off and green goes on.'),('Remove the flyback diode (briefly!)','It works, but the transistor gets spikes: it may die over time.'),('Use a 9 V battery for the coil too','A 5 V relay on 9 V gets hot: match the coil voltage.')]),
 ('p8','8','Microchips','s555','555 blinker (and buzzer)',
  'The classic first chip project.',
  ['NE555, 9 V battery','R1 1 kΩ, R2 10–100 kΩ','C 10 µF','LED + 470 Ω','(variant) 10 nF capacitor + small speaker or piezo'],
  ['Pins: 8 & 4 → +9 V, 1 → −.','R1 between 8 and 7, R2 between 7 and 6, link 6–2.','C from 2/6 to −. Pin 3 → 470 Ω → LED → −.'],
  [('Change R2 (10 k → 100 k)','Slower blinking.'),('C 10 µF → 100 µF','10× slower.'),('C 10 nF + speaker on pin 3','A tone you can hear!'),('A pot as R2','An adjustable speed (or pitch).')]),
 ('p9','9','Microchips','s4017','LED chaser: 555 + CD4017',
  'Make a light that runs along 10 LEDs.',
  ['The 555 blinker above','CD4017','10 LEDs + 10 × 470 Ω (or one shared, since only one is on at a time)'],
  ['555 pin 3 → 4017 pin 14 (clock).','4017: 16 → +, 8 → −, 13 → −, 15 → − (reset).','Each output Q0–Q9 → LED → −.'],
  [('Change the 555 speed','The chaser speeds up or slows down.'),('Wire Q5 to pin 15 (reset)','It now counts 0–4 only.'),('Arrange the LEDs in a circle','A spinning-wheel effect.')]),
 ('p10','10','Microchips','s386','Mini speaker amp (LM386)',
  'The core of your Ruby amp: plug in a phone or guitar.',
  ['LM386, 9 V battery','10 kΩ pot (volume)','220 µF + 100 nF + 10 µF capacitors','8 Ω speaker, audio jack'],
  ['Pins 4 → −, 6 → +9 V. Input via the volume pot to pin 3, pin 2 → −.','Pin 5 → 220 µF (+ side) → speaker → −.','100 nF + 10 Ω from pin 5 to − (Zobel). 100 µF across the battery.'],
  [('Add 10 µF between pins 1 and 8','Gain 20 → 200: much louder, and it distorts sooner.'),('Remove the 220 µF','The speaker gets DC: a thump, hum, wasted power.'),('Turn up the volume a lot','Clipping = overdrive.')]),
]
html=''
for pid,num,topic,link,title,goal,parts,steps,var in P:
    html+=f'''
<section id="{pid}">
  <h2><span class="num">{num}</span>{title}</h2>
  <p><span class="qtopic">{topic}</span> {goal} <a class="navlink" href="#{link}">📖 lesson</a></p>
  <canvas id="c{pid}" width="800" height="250"></canvas>
  <div class="grid2" style="margin-top:12px">
    <div><h3 style="margin-top:0">🧰 You need</h3><ul>{''.join(f'<li>{x}</li>' for x in parts)}</ul></div>
    <div><h3 style="margin-top:0">🔧 Build</h3><ol>{''.join(f'<li>{x}</li>' for x in steps)}</ol></div>
  </div>
  <h3>🧪 Variants to try</h3>
  <table>{''.join(f'<tr><td>{a}</td><td>{b}</td></tr>' for a,b in var)}</table>
</section>'''
open('circuits_projects.html','w').write(html)
