import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))) if os.path.basename(os.path.dirname(os.path.abspath(__file__))) in ('generators','legacy') else os.path.dirname(os.path.abspath(__file__)))
from paths import SRC, PAGES, SITE
import json
R,B,Y,O,U,G,P='#dc2626','#111','#ca8a04','#ea580c','#2563eb','#16a34a','#9333ea'
def batt(s): return dict(s=s,t='batt',at=[40,30],plus='tp1',minus='tn2')
RAILS=[dict(s=1,t='wire',a='tp60',b='bp60',c=R),dict(s=1,t='wire',a='tn59',b='bn59',c=B)]
RAILS_TXT="Battery disconnected. Link the rails at the right end: top <b>+</b> ↔ bottom <b>+</b> (column 60), top <b>−</b> ↔ bottom <b>−</b> (column 59)."

# ---------------- p16: two-LED flip-flop (astable multivibrator) ----------------
p16=[dict(s=1,t='npn',c='c10',b='c11',e='c12'),dict(s=1,t='npn',c='c30',b='c31',e='c32'),
     dict(s=1,t='wire',a='a12',b='tn13',c=B),dict(s=1,t='wire',a='a32',b='tn33',c=B),
     dict(s=2,t='res',a='tp7',b='a7',v=470),dict(s=2,t='led',a='b7',b='b10',blink=1),
     dict(s=2,t='res',a='tp27',b='a27',v=470),dict(s=2,t='led',a='b27',b='b30',rgb='34,197,94',blink=2),
     dict(s=3,t='res',a='tp11',b='a11',v=47000),dict(s=3,t='res',a='tp31',b='a31',v=47000),
     dict(s=4,t='ecap',a='e10',b='e14',lab='10µ'),dict(s=4,t='wire',a='d14',b='d31',c=O),
     dict(s=5,t='ecap',a='e30',b='e26',lab='10µ'),dict(s=5,t='wire',a='d26',b='d11',c=U),batt(6)]
p16_steps=[
 "Battery disconnected. Two <b>BC547</b> in the top half, flat side facing you (C B E): <b>Q1</b> in <b>c10–c12</b>, <b>Q2</b> in <b>c30–c32</b>. Emitters to the top − rail: jumpers <b>a12 → tn13</b> and <b>a32 → tn33</b>.",
 "The LEDs and their resistors. <b>470 Ω</b> from top + to <b>a7</b>, red LED from <b>b7</b> (long leg) to <b>b10</b> (short leg, Q1's collector). <b>470 Ω</b> from top + to <b>a27</b>, green LED from <b>b27</b> (long leg) to <b>b30</b> (Q2's collector).",
 "Base resistors, the \"refill pipes\": <b>47 kΩ</b> from top + to <b>a11</b> (Q1 base) and <b>47 kΩ</b> from top + to <b>a31</b> (Q2 base).",
 "Cross-link 1: <b>10 µF</b> with its <b>+ leg in e10</b> (Q1 collector) and − leg in <b>e14</b>. Jumper <b>d14 → d31</b> (Q2 base).",
 "Cross-link 2: <b>10 µF</b> with its <b>+ leg in e30</b> (Q2 collector) and − leg in <b>e26</b>. Jumper <b>d26 → d11</b> (Q1 base). The two capacitors make an \"X\" between the transistors.",
 "Connect the battery (red → top +, black → top −). The LEDs take turns, about 1.5 times per second."]
p16_how=[
 "Two transistors, each one able to switch the other <b>off</b> for a moment. When Q1 turns on, its collector drops from ~9 V to ~0 V. The capacitor linking it to Q2's base passes that sudden drop on, and pushes Q2's base <b>below 0 V</b>: Q2 is slammed off.",
 "Then Q2's base slowly climbs back up as its 47 kΩ resistor refills the capacitor. When it reaches ~0.6 V, Q2 turns on, its collector drops, and the other capacitor slams <b>Q1</b> off. And so on, forever: a <b>see-saw</b> that tips itself.",
 "<b>Water analogy:</b> two buckets on a see-saw, each slowly filled by a thin pipe (the 47 kΩ). When one is full it tips the see-saw, which empties the other bucket. Time per side ≈ 0.7 × R × C = 0.7 × 47 kΩ × 10 µF ≈ <b>0.33 s</b>.",
 "This is exactly the job a 555 does (project 8), but built from loose parts. It's also the oldest oscillator in electronics: the \"astable multivibrator\" from 1917, then with vacuum tubes."]

# ---------------- p17: police siren (two 555) ----------------
p17=RAILS+[
 dict(s=2,t='chip',col=4,n=8,lab='555'),dict(s=2,t='wire',a='d4',b='tp4',c=R),dict(s=2,t='wire',a='j4',b='bn4',c=B),dict(s=2,t='wire',a='j7',b='bp7',c=R),
 dict(s=3,t='res',a='c4',b='c5',v=1000),dict(s=3,t='res',a='b5',b='b6',v=47000),dict(s=3,t='wire',a='a6',b='i5',c=U),dict(s=3,t='ecap',a='h5',b='bn5',lab='10µ'),
 dict(s=4,t='res',a='i6',b='i10',v=470),dict(s=4,t='led',a='h10',b='h13',blink=1),dict(s=4,t='wire',a='j13',b='bn13',c=B),
 dict(s=5,t='chip',col=20,n=8,lab='555'),dict(s=5,t='wire',a='d20',b='tp20',c=R),dict(s=5,t='wire',a='j20',b='bn20',c=B),dict(s=5,t='wire',a='j23',b='bp23',c=R),
 dict(s=6,t='res',a='c20',b='c21',v=1000),dict(s=6,t='res',a='b21',b='b22',v=10000),dict(s=6,t='wire',a='a22',b='i21',c=U),dict(s=6,t='ccap',a='h21',b='bn21',lab='100n'),
 dict(s=7,t='wire',a='h6',b='a14',c=P),dict(s=7,t='res',a='b14',b='b23',v=10000),
 dict(s=8,t='res',a='h22',b='h30',v=220),
 dict(s=8,t='box',at=[380,352],w=130,h=46,lab='🔊 8 Ω speaker',col='#374151',ly=28,pins=[{'n':'','dx':18,'dy':0,'to':'j30','c':Y},{'n':'','dx':112,'dy':0,'to':'bn32','c':B}]),
 batt(9)]
p17_steps=[RAILS_TXT,
 "<b>555 #1</b> (the slow one) across the gap, notch left, columns <b>4–7</b>. <b>d4</b> (pin 8) → top +, <b>j4</b> (pin 1) → bottom −, <b>j7</b> (pin 4, reset) → bottom + so it always runs.",
 "Slow timing: <b>1 kΩ</b> c4→c5, <b>47 kΩ</b> b5→b6, jumper <b>a6 → i5</b> (pin 6 → pin 2), <b>10 µF</b> + leg in <b>h5</b>, − leg in the bottom − rail. About 1.5 switches per second.",
 "A \"see the slow clock\" LED: <b>470 Ω</b> from <b>i6</b> (pin 3) to <b>i10</b>, LED long leg <b>h10</b>, short leg <b>h13</b>, jumper <b>j13</b> → bottom −.",
 "<b>555 #2</b> (the tone) across the gap, columns <b>20–23</b>. <b>d20</b> → top +, <b>j20</b> → bottom −, <b>j23</b> (reset) → bottom +.",
 "Tone timing: <b>1 kΩ</b> c20→c21, <b>10 kΩ</b> b21→b22, jumper <b>a22 → i21</b>, <b>100 nF</b> from <b>h21</b> to the bottom − rail. Alone, this would beep at ~690 Hz.",
 "The link that makes it a siren: jumper <b>h6 → a14</b> (555 #1 output), then <b>10 kΩ</b> from <b>b14</b> to <b>b23</b> (555 #2 pin 5, CTRL).",
 "Speaker: <b>220 Ω</b> from <b>h22</b> (555 #2 output) to <b>h30</b>. Speaker wires: one to <b>j30</b>, the other to the bottom − rail.",
 "Connect the battery: pin-pon, pin-pon! 🚓"]
p17_how=[
 "Two 555 timers, one controlling the other. <b>555 #2</b> makes the sound: ~600–900 pulses per second, which the speaker turns into a tone. <b>555 #1</b> is slow: it flips its output between 9 V and 0 V about 1.5 times per second (the LED shows it).",
 "The trick is <b>pin 5 (CTRL)</b> of 555 #2: it's the ⅔ point of its internal divider (see the <a class=\"navlink\" href=\"#s555\">555 pinout</a>). Pull it up through 10 kΩ and the capacitor must fill higher before flipping, so each cycle is longer: a <b>lower note</b>. Pull it down and the note goes <b>higher</b>. Result: two alternating notes, the French \"pin-pon\".",
 "<b>Water analogy:</b> the tone 555 is a tank that empties each time it reaches the high mark. 555 #1 keeps sliding that high mark up and down, so the tank takes longer or shorter to fill: the rhythm (the pitch) changes.",
 "Want the American \"wail\" instead? Add a <b>100 µF</b> from 555 #2 pin 5 to −. It smooths the jumps, so the pitch <b>glides</b> up and down instead of switching."]

# ---------------- p18: fuzz pedal ----------------
p18=[dict(s=1,t='npn',c='c20',b='c21',e='c22'),dict(s=1,t='wire',a='a22',b='tn22',c=B),
     dict(s=1,t='npn',c='c30',b='c31',e='c32'),dict(s=1,t='wire',a='b20',b='b31',c=Y),
     dict(s=2,t='res',a='tp19',b='a20',v=33000),
     dict(s=3,t='res',a='tp25',b='b26',v=470),dict(s=3,t='pot',h=['a26','a27','a28']),dict(s=3,t='wire',a='c27',b='a30',c=O),
     dict(s=4,t='res',a='a32',b='tn33',v=1000),dict(s=4,t='ecap',a='b32',b='tn34',lab='22µ'),
     dict(s=5,t='res',a='e32',b='e21',v=100000),
     dict(s=6,t='ecap',a='d21',b='d17',lab='2.2µ'),
     dict(s=6,t='box',at=[150,22],w=110,h=40,lab='🎸 IN jack',col='#374151',ly=24,pins=[{'n':'tip','dx':22,'dy':40,'to':'a17','c':Y},{'n':'sleeve','dx':86,'dy':40,'to':'tn16','c':B}]),
     dict(s=7,t='ccap',a='d30',b='d35',lab='10n'),
     dict(s=7,t='box',at=[440,22],w=130,h=40,lab='OUT → Ruby amp',col='#374151',ly=24,pins=[{'n':'tip','dx':20,'dy':40,'to':'a35','c':Y},{'n':'sleeve','dx':104,'dy':40,'to':'tn37','c':B}]),
     batt(8)]
p18_steps=[
 "Battery disconnected. Two <b>BC547</b> in the top half, flat side facing you (C B E): <b>Q1</b> in <b>c20–c22</b>, <b>Q2</b> in <b>c30–c32</b>. Q1's emitter to ground: <b>a22 → top −</b>. Q1's collector drives Q2's base directly: jumper <b>b20 → b31</b>.",
 "Q1's collector resistor: <b>33 kΩ</b> from top + to <b>a20</b>.",
 "Q2's collector load: <b>470 Ω</b> from top + to <b>b26</b>, the <b>10 kΩ trimmer</b> in <b>a26–a28</b> (used as a variable resistor: pins 1 and 2), and jumper <b>c27 → a30</b> (wiper → Q2 collector). This trimmer is the <b>bias</b> knob.",
 "Q2's emitter: <b>1 kΩ</b> from <b>a32</b> to top −, and <b>22 µF</b> with its <b>+ leg in b32</b> and − leg in top −. This capacitor gives the full fuzz.",
 "The feedback resistor that keeps everything balanced: <b>100 kΩ</b> from <b>e32</b> (Q2 emitter) to <b>e21</b> (Q1 base).",
 "Input: <b>2.2 µF</b>, <b>+ leg in d21</b> (Q1 base), − leg in <b>d17</b>. Input jack (solder two wires to it): tip → <b>a17</b>, sleeve → top −.",
 "Output: <b>10 nF</b> from <b>d30</b> (Q2 collector) to <b>d35</b>. Output jack: tip → <b>a35</b>, sleeve → top −.",
 "Connect the battery. Guitar → IN, OUT → your Ruby (volume low first!). Play and turn the trimmer: find the spot where the fuzz sounds fat and sustains (Q2's collector at ≈ 4.5 V if you have a multimeter)."]
p18_how=[
 "This is a silicon <b>\"Fuzz Face\"</b>, the 1966 pedal heard on countless 60s/70s records. It's just two transistors in a row, with so much gain (~100 × 100) that a guitar note is amplified far beyond what the 9 V supply can hold.",
 "So the wave gets <b>clipped</b>: its tops and bottoms are sliced flat, and a smooth vibrating string turns into an almost <b>square</b> wave. Square waves are full of extra harmonics: that's the buzzy, sustaining fuzz sound. Same idea as the Ruby's overdrive, pushed much further.",
 "<b>Water analogy:</b> a powerful pump (the transistors) pushing water through a pipe with a ceiling and a floor (9 V and 0 V). Small waves pass, but the pump makes them so big they bang against the ceiling and floor and come out flat-topped.",
 "The <b>100 kΩ feedback</b> resistor holds both transistors at the right resting point, the <b>22 µF</b> on Q2's emitter sets how much gain the music sees (more capacitance = more fuzz), and the <b>trimmer</b> sets Q2's resting voltage: too high or too low and the fuzz becomes thin, gated and \"sputtery\". The 2.2 µF and 10 nF are the usual coupling capacitors that pass the music but block DC."]

# ---------------- p19: 2-digit counter 00-99 ----------------
def seg_res(X,Y):
    f,g,a,b,c,d,e=X+1,X+2,X+3,X+4,X+5,X+6,X+7
    return [(f'a{f}',f'a{Y+1}'),(f'b{g}',f'b{Y}'),(f'c{a}',f'c{Y+3}'),(f'd{b}',f'd{Y+4}'),(f'a{c}',f'g{Y+3}'),(f'a{d}',f'h{Y+1}'),(f'a{e}',f'i{Y}')]
p19=RAILS+[
 dict(s=2,t='chip',col=3,n=8,lab='555'),dict(s=2,t='wire',a='d3',b='tp3',c=R),dict(s=2,t='wire',a='j3',b='bn3',c=B),dict(s=2,t='wire',a='j6',b='bp7',c=R),
 dict(s=2,t='res',a='c3',b='c4',v=1000),dict(s=2,t='res',a='b4',b='b5',v=47000),dict(s=2,t='wire',a='a5',b='i4',c=U),dict(s=2,t='ecap',a='h4',b='bn4',lab='10µ'),
 dict(s=3,t='chip',col=9,n=16,lab='CD4518'),dict(s=3,t='wire',a='d9',b='tp9',c=R),dict(s=3,t='wire',a='j16',b='bn16',c=B),
 dict(s=3,t='wire',a='j10',b='bp10',c=R),dict(s=3,t='wire',a='a16',b='tn16',c=B),dict(s=3,t='wire',a='h5',b='h9',c=Y),
 dict(s=4,t='wire',a='g14',b='b15',c=O),dict(s=4,t='wire',a='b10',b='h15',c=P),dict(s=4,t='res',a='i15',b='bn15',v=10000),
 dict(s=4,t='btn',col=50),dict(s=4,t='wire',a='tp50',b='a50',c=R),dict(s=4,t='wire',a='i52',b='j15',c=P),
 dict(s=5,t='chip',col=19,n=16,lab='CD4511'),dict(s=5,t='wire',a='d19',b='tp19',c=R),dict(s=5,t='wire',a='j26',b='bn26',c=B),
 dict(s=5,t='wire',a='j21',b='bp21',c=R),dict(s=5,t='wire',a='j22',b='bp22',c=R),dict(s=5,t='wire',a='j23',b='bn23',c=B),
 dict(s=6,t='wire',a='a14',b='i25',c=G),dict(s=6,t='wire',a='a13',b='i19',c=U),dict(s=6,t='wire',a='c12',b='h20',c=P),dict(s=6,t='wire',a='b11',b='h24',c=O),
 dict(s=7,t='seg7',col=28,show='CNT',place=1),dict(s=7,t='wire',a='j30',b='bn31',c=B)]+\
 [dict(s=8,t='res',a=a,b=b,v=1000) for a,b in seg_res(19,28)]+[
 dict(s=9,t='chip',col=35,n=16,lab='CD4511'),dict(s=9,t='wire',a='d35',b='tp35',c=R),dict(s=9,t='wire',a='j42',b='bn43',c=B),
 dict(s=9,t='wire',a='j37',b='bp37',c=R),dict(s=9,t='wire',a='j38',b='bp38',c=R),dict(s=9,t='wire',a='j39',b='bn39',c=B),
 dict(s=10,t='wire',a='i11',b='i41',c=G),dict(s=10,t='wire',a='i12',b='i35',c=U),dict(s=10,t='wire',a='i13',b='i36',c=P),dict(s=10,t='wire',a='h14',b='i40',c=O),
 dict(s=11,t='seg7',col=44,show='CNT',place=0),dict(s=11,t='wire',a='j46',b='bn47',c=B)]+\
 [dict(s=12,t='res',a=a,b=b,v=1000) for a,b in seg_res(35,44)]+[batt(13)]
def rtxt(X,Y):
    names='f g a b c d e'.split();return ', '.join(f"{n} <b>{a}→{b}</b>" for n,(a,b) in zip(names,seg_res(X,Y)))
p19_steps=[RAILS_TXT,
 "The clock: <b>NE555</b> across the gap, notch left, columns <b>3–6</b>. <b>d3</b> → top +, <b>j3</b> → bottom −, <b>j6</b> (reset) → bottom +. Timing: <b>1 kΩ</b> c3→c4, <b>47 kΩ</b> b4→b5, jumper <b>a5 → i4</b>, <b>10 µF</b> + leg <b>h4</b>, − leg bottom −. ≈ 1.5 ticks per second.",
 "<b>CD4518</b> (dual BCD counter) across the gap, notch left, columns <b>9–16</b> (bottom pins 1–8: CLK A, EN A, Q1A–Q4A, RST A, VSS; top pins 16–9: VDD, RST B, Q4B–Q1B, EN B, CLK B). <b>d9</b> → top +, <b>j16</b> → bottom −, <b>j10</b> (EN A) → bottom +, <b>a16</b> (CLK B) → top −. Clock: jumper <b>h5 → h9</b> (555 pin 3 → CLK A).",
 "Chain the two counters: jumper <b>g14 → b15</b> (Q4A → EN B: the units' \"8\" bit falls when going 9 → 0 and ticks the tens). Reset: jumper <b>b10 → h15</b> (RST B → RST A), <b>10 kΩ</b> from <b>i15</b> to bottom −, push button at columns <b>50–52</b>, jumper top + → <b>a50</b>, jumper <b>i52 → j15</b>.",
 "Tens decoder: <b>CD4511</b>, columns <b>19–26</b> (bottom: B C LT BI LE D A VSS; top: VDD f g a b c d e). <b>d19</b> → top +, <b>j26</b> → bottom −, <b>j21</b> (LT) and <b>j22</b> (BI) → bottom +, <b>j23</b> (LE) → bottom −.",
 "Tens number into the decoder: <b>a14 → i25</b> (Q1B → A), <b>a13 → i19</b> (Q2B → B), <b>c12 → h20</b> (Q3B → C), <b>b11 → h24</b> (Q4B → D).",
 "Tens display (SC39-11SURKWA) across the gap, columns <b>28–32</b>. COM: <b>j30</b> → bottom −.",
 "Tens segment resistors, <b>1 kΩ</b> each: "+rtxt(19,28)+". The last three cross the gap.",
 "Units decoder: <b>CD4511</b>, columns <b>35–42</b>. <b>d35</b> → top +, <b>j42</b> → bottom −, <b>j37</b> (LT) and <b>j38</b> (BI) → bottom +, <b>j39</b> (LE) → bottom −.",
 "Units number into the decoder: <b>i11 → i41</b> (Q1A → A), <b>i12 → i35</b> (Q2A → B), <b>i13 → i36</b> (Q3A → C), <b>h14 → i40</b> (Q4A → D).",
 "Units display, columns <b>44–48</b>. COM: <b>j46</b> → bottom −.",
 "Units segment resistors, <b>1 kΩ</b> each: "+rtxt(35,44)+".",
 "Connect the battery: 00, 01, 02 … 99, 00. Press the button to go back to 00. (Two displays drain a 9 V battery in a few hours: the USB power module at 5 V works too, a little dimmer.)"]
p19_how=[
 "The <b>555</b> ticks about 1.5 times per second. The <b>CD4518</b> contains two counters that count in <b>BCD</b> (binary-coded decimal): 0000, 0001 … 1001 (9), then back to 0000. Its 4 outputs Q1–Q4 are worth 1, 2, 4 and 8: for a \"6\", Q2 and Q3 are on (2 + 4).",
 "<b>Carrying over:</b> the units counter's Q4 (the \"8\") is on for 8 and 9, and drops when it rolls over from 9 to 0. Wired to the tens counter's ENABLE, that drop counts as one tick: exactly like 09 → 10 on paper.",
 "Each 4-bit number goes into a <b>CD4511</b>, which lights the right segments of its display (with 1 kΩ per segment). Same decoder as dice project 15, just twice.",
 "<b>Water analogy:</b> a bucket (the units) fills one cup per tick. When it holds the 10th cup it tips over, pours one cup into the next bucket (the tens), and starts empty again."]

LAY={'p16':{'power':6,'parts':p16},'p17':{'power':9,'parts':p17},'p18':{'power':8,'parts':p18},'p19':{'power':13,'parts':p19}}
STEPS={'p16':p16_steps,'p17':p17_steps,'p18':p18_steps,'p19':p19_steps}
HOW={'p16':p16_how,'p17':p17_how,'p18':p18_how,'p19':p19_how}
if __name__=='__main__':
    print({k:len(v) for k,v in STEPS.items()},{k:max(p['s'] for p in v['parts']) for k,v in LAY.items()})
