import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))) if os.path.basename(os.path.dirname(os.path.abspath(__file__))) in ('generators','legacy') else os.path.dirname(os.path.abspath(__file__)))
from paths import SRC, PAGES, SITE
import sys
HUB,RES=sys.argv[1],sys.argv[2]
css=open('style2.css.html').read()
links=open('links.js.html').read().replace('@HUB@',HUB).replace('@RES@',RES)
hubcss=css.replace('</style>','''  .comp-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:14px}
  .comp{display:flex;gap:14px;align-items:flex-start;border:1px solid var(--line);border-radius:12px;padding:16px;background:#101827;color:var(--ink);text-decoration:none;transition:.15s}
  a.comp:hover{border-color:#3b82f6;transform:translateY(-2px)}
  .comp svg{width:96px;flex-shrink:0;margin-top:8px;overflow:visible}
  .comp h3{margin:0 0 4px}.comp p{margin:0 0 6px;color:var(--muted);font-size:.95rem}
  .comp .analogy{color:#93c5fd}.comp .open{font-weight:700;color:#60a5fa}
  .soon .comp{opacity:.6}
</style>''')
def page(title,body,script=''):
    return f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="color-scheme" content="dark">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
{hubcss if title.startswith('Electronics') else css}
</head>
<body>
{body}
{script}
{links}
</body>
</html>'''
open(PAGES+'index.html','w').write(page('Electronics Learning: Components',open('hub_body.html').read()))
open(PAGES+'resistor.html','w').write(page('How a Resistor Works',open('resistor_body.html').read(),'<script>\n'+open('helpers.js').read()+open('resistor.js').read()+'\n</script>'))
# capacitor: add nav + css + links
p=PAGES+'capacitor.html';s=open(p).read()
if 'data-page="hub"' not in s:
    s=s.replace('<main>\n','<main>\n<nav style="margin:4px 0 0"><a data-page="hub" class="navlink">← All components</a></nav>\n',1)
    s=s.replace('</style>','  .navlink{color:#93c5fd;text-decoration:none;font-weight:600;cursor:pointer}\n  .navlink:hover{text-decoration:underline}\n</style>',1)
    s=s.replace('a resistor controls how fast','a resistor controls how fast')
import re
s=re.sub(r'<script>\nconst LINKS=.*?</script>\n','',s,flags=re.S)
s=s.replace('</body>',links+'\n</body>')
open(p,'w').write(s)
