import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))) if os.path.basename(os.path.dirname(os.path.abspath(__file__))) in ('generators','legacy') else os.path.dirname(os.path.abspath(__file__)))
from paths import SRC, PAGES, SITE
import json,re,sys
U=json.load(open('urls.json'))
css=open('style2.css.html').read()
links='<script>\nconst LINKS='+json.dumps({k:{'web':v,'file':('index' if k=='hub' else k)+'.html'} for k,v in U.items()})+''';
document.querySelectorAll('a[data-page]').forEach(a=>{const l=LINKS[a.dataset.page];if(!l)return;const local=location.protocol==='file:';a.href=local?l.file:l.web;if(!local)a.target='_blank';});
</script>'''
hubcss=css.replace('</style>','''  .comp-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:14px}
  .comp{display:flex;gap:14px;align-items:flex-start;border:1px solid var(--line);border-radius:12px;padding:16px;background:#101827;color:var(--ink);text-decoration:none;transition:.15s}
  a.comp:hover{border-color:#3b82f6;transform:translateY(-2px)}
  .comp svg{width:96px;flex-shrink:0;margin-top:8px;overflow:visible}
  .comp h3{margin:0 0 4px}.comp p{margin:0 0 6px;color:var(--muted);font-size:.95rem}
  .comp .analogy{color:#93c5fd}.comp .open{font-weight:700;color:#60a5fa}
  .soon .comp{opacity:.6}
</style>''')
H=open('helpers.js').read()
def page(title,body,js='',c=css):
    return f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="color-scheme" content="dark">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
{c}
</head>
<body>
{body}
{('<script>'+chr(10)+H+js+chr(10)+'</script>') if js else ''}
{links}
</body>
</html>'''
O=PAGES
open(O+'index.html','w').write(page('Electronics Learning: Components',open('hub_body.html').read(),c=hubcss))
open(O+'resistor.html','w').write(page('How a Resistor Works',open('resistor_body.html').read(),open('resistor.js').read()))
extra={'led':open('diode.js').read().split('// ===== 3.')[0]}  # LED page doesn't need diode helpers
open(O+'diode.html','w').write(page('How a Diode Works',open('diode_body.html').read(),open('diode.js').read()))
open(O+'led.html','w').write(page('How an LED Works',open('led_body.html').read(),open('led.js').read()))
open(O+'chips.html','w').write(page('Common Microchips',open('chips_body.html').read(),open('chips.js').read()+open('chipx.js').read()+open('chipmin.js').read()))
open(O+'transistor.html','w').write(page('How a Transistor Works',open('transistor_body.html').read(),open('transistor.js').read()))
p=O+'capacitor.html';s=open(p).read()
s=re.sub(r'<script>\nconst LINKS=.*?</script>\n?','',s,flags=re.S)
s=s.replace('</body>',links+'\n</body>')
open(p,'w').write(s)
