import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))) if os.path.basename(os.path.dirname(os.path.abspath(__file__))) in ('generators','legacy') else os.path.dirname(os.path.abspath(__file__)))
from paths import SRC, PAGES, SITE
# Step-by-step wiring guides + "how it works" for each circuit
G={}
G['p1']=dict(how=[
 "The battery pushes current around one single loop: <b>+ → resistor → LED → −</b>. The resistor is the narrow pipe that sets how much current can flow, and the LED glows brighter with more current.",
 "The red LED always \"uses\" about 2 V of the 9 V. The other 7 V is dropped across the resistor, so the current is <b>I = 7 V ÷ R</b>: 220 Ω gives 32 mA (too much!), 470 Ω gives 15 mA, 1 kΩ gives 7 mA, and 10 kΩ gives 0.7 mA (a faint glow).",
 "Series resistors add up (harder to flow, dimmer). Parallel resistors give the current two paths (easier, brighter)."],
 steps=[
 "Keep the battery <b>disconnected</b> while wiring. Put the breadboard with the red <b>+</b> rail at the top.",
 "Put one leg of the <b>470 Ω</b> resistor into the top <b>+</b> rail and the other leg into hole <b>a10</b> (column 10).",
 "Put the LED's <b>long leg</b> (+) into <b>c10</b>, the same column as the resistor, and its <b>short leg</b> into <b>c13</b>.",
 "Plug a jumper wire from <b>a13</b> to the top <b>−</b> rail (blue).",
 "Clip the 9 V snap: <b>red</b> wire into the <b>+</b> rail, <b>black</b> wire into the <b>−</b> rail.",
 "Snap on the battery: the LED lights. If it doesn't, turn the LED round.",
 "To try another resistor: <b>unclip the battery first</b>, swap the resistor, then reconnect."])
G['p2']=dict(how=[
 "While you hold the button, the battery feeds two things at once: the LED (through its resistor) and the big <b>capacitor</b>, which fills up to 9 V almost instantly.",
 "When you let go, the battery is disconnected. The capacitor now acts like a small water tank: it empties <b>through the resistor and the LED</b>, so the LED keeps glowing.",
 "As the capacitor empties, its voltage drops, the current drops, and the LED fades. A bigger capacitor (more water) or a bigger resistor (narrower pipe) makes the fade last longer: roughly <b>time ≈ R × C</b>."],
 steps=[
 "Battery disconnected. Link the rails: jumper from top <b>+</b> to bottom <b>+</b>, and from top <b>−</b> to bottom <b>−</b>.",
 "Push the <b>button</b> across the centre gap at columns <b>5–7</b>: two legs in the top half (row e), two in the bottom half (row f).",
 "Jumper from the top <b>+</b> rail to <b>a5</b> (the button's top-left leg).",
 "Plug the <b>1000 µF</b> capacitor: <b>long leg (+)</b> into <b>j7</b> (bottom half, same column as the button's bottom-right leg), <b>striped leg (−)</b> into the bottom <b>−</b> rail.",
 "Put the <b>470 Ω</b> resistor from <b>h7</b> to <b>h15</b>.",
 "LED: <b>long leg</b> into <b>g15</b>, <b>short leg</b> into <b>g18</b>. Jumper from <b>j18</b> to the bottom <b>−</b> rail.",
 "Connect the battery. Hold the button for one second, then release: the LED fades out. (If the LED is always on or never on, rotate the button 90°.)"])
G['p3']=dict(how=[
 "Each LED is a <b>one-way valve</b> that lights. The two LEDs are connected side by side but pointing <b>opposite ways</b>, so whichever way the current flows, exactly one of them can conduct.",
 "If + is on test wire A, current flows A → resistor → red LED → B. Swap the wires and it flows B → green LED → resistor → A. The 1 kΩ protects both LEDs (≈ 7 mA)."],
 steps=[
 "Put the <b>1 kΩ</b> resistor from <b>a10</b> to <b>a14</b>.",
 "<b>Red</b> LED: long leg in <b>c14</b>, short leg in <b>c18</b>.",
 "<b>Green</b> LED, the <b>other way</b>: long leg in <b>e18</b>, short leg in <b>e14</b>.",
 "Test wire <b>A</b>: a jumper in <b>d10</b>. Test wire <b>B</b>: a jumper in <b>d18</b>.",
 "Touch A to the battery <b>+</b> and B to <b>−</b>: red lights. Swap them: green lights."])
G['p4']=dict(how=[
 "Three identical, independent loops share the same battery: <b>+ → button → 470 Ω → LED → −</b>. Each button closes its own loop.",
 "Because each LED has its <b>own</b> resistor, each gets its own ≈ 15 mA no matter how many are on. With one shared resistor, the LED with the lowest forward voltage would hog the current."],
 steps=[
 "Battery disconnected, red <b>+</b> rail at the top.",
 "Place 3 buttons across the gap at columns <b>10–12</b>, <b>25–27</b> and <b>40–42</b>.",
 "For each button: jumper from the top <b>+</b> rail to the button's top-left leg (<b>a10</b>, <b>a25</b>, <b>a40</b>).",
 "For each button: a <b>470 Ω</b> resistor from its bottom-right leg (<b>j12</b>, <b>j27</b>, <b>j42</b>) to a free column (<b>j16</b>, <b>j31</b>, <b>j46</b>).",
 "LEDs: <b>long leg</b> in that column (<b>h16</b>, <b>h31</b>, <b>h46</b>), <b>short leg</b> 2 columns further (<b>h18</b>, <b>h33</b>, <b>h48</b>). Red, yellow, green.",
 "Jumpers from <b>j18</b>, <b>j33</b> and <b>j48</b> to the bottom <b>−</b> rail. Link the top and bottom <b>−</b> rails.",
 "Connect the battery and press the buttons in traffic-light order."])
G['p5']=dict(how=[
 "Your skin conducts a <b>tiny</b> current (a few µA) between the two pads. That's far too little to light an LED.",
 "Transistor 1 amplifies it about 100×, and its output feeds the base of transistor 2, which amplifies it about 100× again. Together (a <b>Darlington pair</b>) that's ×10,000: a few µA through your finger become a few mA through the LED.",
 "The 1 kΩ protects the base if the pads touch each other directly, and the 470 Ω limits the LED current."],
 steps=[
 "Battery disconnected. Hold each <b>BC547</b> with the <b>flat side facing you</b>: the legs are <b>C B E</b> from left to right.",
 "Transistor 1 in <b>c20 c21 c22</b> (C B E). Transistor 2 in <b>c30 c31 c32</b>.",
 "Jumper from <b>e22</b> (E1) to <b>e31</b> (B2): this makes the Darlington pair.",
 "Jumper <b>d20 → d30</b> to link both collectors.",
 "Jumper from <b>b32</b> (E2) to the top <b>−</b> rail.",
 "LED: <b>short leg</b> in <b>a30</b> (the collectors), <b>long leg</b> in <b>a36</b>. Then <b>470 Ω</b> from <b>b36</b> to the top <b>+</b> rail.",
 "Touch pads: <b>1 kΩ</b> from the top <b>+</b> rail to <b>a12</b>. A jumper with a bare end in <b>b12</b> is pad A. A jumper with a bare end in <b>b21</b> (B1) is pad B.",
 "Connect the battery (red → top +, black → top −) and touch both bare ends with one finger: the LED lights."
])
G['p6']=dict(how=[
 "While the button is pressed, current flows through the coil and builds a magnetic field (the heavy water wheel spinning up). The LED is connected <b>backwards</b>, so it stays dark.",
 "When you release the button, the coil's current can't stop instantly. It forces a voltage spike in the <b>opposite direction</b>, which makes the backwards LED conduct for a split second: a <b>flash</b>.",
 "A flyback diode in the same position absorbs that spike silently: that's exactly why relays and motors need one."],
 steps=[
 "Find the <b>coil pins</b> of the relay: with a multimeter on Ω, the two pins showing ≈ 70 Ω are the coil. Solder a short wire to each.",
 "Button across the gap at columns <b>10–12</b>. Jumper from the top <b>+</b> rail to <b>a10</b>.",
 "Coil wire 1 into <b>j12</b> (the button's other side). Coil wire 2 into the bottom <b>−</b> rail.",
 "LED <b>backwards</b> across the coil: <b>short leg</b> in <b>h12</b>, <b>long leg</b> in the bottom <b>−</b> rail.",
 "Link the top and bottom <b>−</b> rails, then connect the 9 V battery (red → top +, black → top −).",
 "Press for a second, then release: watch the LED flash at the moment you let go.",
 "Variant: replace the LED with a <b>1N4007</b> (stripe on the h12 side): no more flash."
])
G['p7']=dict(how=[
 "The button sends a small current through the 1 kΩ into the transistor's base. The transistor switches on and lets the bigger coil current (≈ 70 mA) flow through the relay coil.",
 "The coil becomes an electromagnet and pulls the switch arm: <b>COM</b> leaves <b>NC</b> (red LED off) and touches <b>NO</b> (green LED on). <i>Click!</i>",
 "When you release, the coil's field collapses. The <b>flyback diode</b> catches the spike so the transistor isn't damaged. The 10 kΩ pull-down keeps the base firmly off when the button isn't pressed."],
 steps=[
 "Plug the SD80A <b>power module</b> on the left end of the board (it feeds both rail pairs) and set both jumpers to <b>5 V</b>. Leave it switched <b>off</b>.",
 "BC547 in the bottom half: <b>h20 h21 h22</b> (C B E, flat side facing you). Jumper <b>j22</b> (E) → bottom <b>−</b> rail.",
 "Button across the gap at columns <b>10–12</b>. Jumper from the top <b>+</b> rail to <b>a10</b>.",
 "<b>1 kΩ</b> from <b>j12</b> to <b>j21</b> (base). <b>10 kΩ</b> from <b>i21</b> to the bottom <b>−</b> rail.",
 "Relay coil: one coil wire to the bottom <b>+</b> rail, the other to <b>g20</b> (collector).",
 "<b>1N4007</b> across the coil: plain end in <b>f20</b>, <b>striped end</b> in the bottom <b>+</b> rail.",
 "Contacts: <b>COM</b> wire to the top <b>+</b> rail, <b>NC</b> wire to <b>a45</b>, <b>NO</b> wire to <b>a55</b>.",
 "Red LED: <b>220 Ω</b> from <b>b45</b> to <b>b48</b>, LED long leg <b>c48</b>, short leg <b>c49</b>, jumper <b>d49</b> → top <b>−</b>. Green the same way: <b>b55→b58</b>, LED <b>c58/c59</b>, <b>d59</b> → top <b>−</b>.",
 "Switch the power module on: red is lit. Press the button: <i>click</i>, green."
])
G['p8']=dict(how=[
 "The 10 µF capacitor fills through <b>R1 + R2</b>. Inside the 555, two comparators watch its voltage.",
 "When it reaches <b>⅔ of 9 V</b>, the 555 turns its output (pin 3) <b>off</b> and opens the discharge pin 7, which empties the capacitor through R2. When it falls to <b>⅓</b>, the output turns back <b>on</b> and filling starts again.",
 "That endless fill/empty cycle makes the LED blink. Frequency ≈ 1.44 ÷ ((R1 + 2·R2) × C): with 1 kΩ, 47 kΩ and 10 µF, about <b>1.5 blinks per second</b>."],
 steps=[
 "Battery disconnected. Link the rails: top <b>+</b> ↔ bottom <b>+</b>, top <b>−</b> ↔ bottom <b>−</b>. Place the <b>NE555</b> across the gap, <b>notch to the left</b>, in columns <b>20–23</b> (pins 1–4 bottom row left→right, pins 8–5 top row left→right).",
 "Power: <b>d20</b> (pin 8) → top <b>+</b>. <b>j23</b> (pin 4) → bottom <b>+</b>. <b>j20</b> (pin 1) → bottom <b>−</b>.",
 "<b>R1 (1 kΩ)</b> from <b>c20</b> (pin 8) to <b>c21</b> (pin 7).",
 "<b>R2 (47 kΩ)</b> from <b>b21</b> (pin 7) to <b>b22</b> (pin 6).",
 "Jumper from <b>a22</b> (pin 6) to <b>j21</b> (pin 2), over the chip.",
 "<b>10 µF</b>: long leg (+) in <b>i21</b> (pin 2), striped leg in the bottom <b>−</b> rail.",
 "Output: <b>470 Ω</b> from <b>h22</b> (pin 3) to <b>h28</b>. LED long leg <b>g28</b>, short leg <b>g30</b>, jumper <b>j30</b> → bottom <b>−</b>.",
 "Optional: <b>10 nF</b> from <b>a23</b> (pin 5) to the top <b>−</b> rail. Connect the battery (red → top +, black → top −): it blinks."
])
G['p9']=dict(how=[
 "The 555 from project 8 produces clock pulses. Each pulse arrives on the CD4017's <b>clock</b> input (pin 14).",
 "Inside, the 4017 counts the pulses and turns on <b>exactly one</b> of its 10 outputs: Q0, then Q1… up to Q9, then back to Q0. Each output lights its LED, so the light runs along the row.",
 "Only one LED is ever on, so a single shared resistor on the LEDs' common side is enough. Wiring an output to <b>reset</b> (pin 15) makes it count to a smaller number."],
 steps=[
 "Battery disconnected. Link <b>only the + rails</b> (top ↔ bottom). The top <b>−</b> rail will be the LEDs' shared line, so <b>don't</b> link the − rails.",
 "555 across the gap, notch left, columns <b>8–11</b>. <b>d8</b> (pin 8) → top +, <b>j11</b> (pin 4) → bottom +, <b>j8</b> (pin 1) → bottom −.",
 "555 timing parts: <b>1 kΩ c8→c9</b>, <b>47 kΩ b9→b10</b>, jumper <b>a10 → i9</b> (pin 6 → pin 2), <b>10 µF</b> + in <b>h9</b>, stripe in bottom −.",
 "<b>CD4017</b> across the gap, notch left, columns <b>35–42</b> (pins 1–8 bottom, 16–9 top). <b>d35</b> (pin 16) → top +, <b>j42</b> (pin 8) → bottom −.",
 "<b>d38</b> (pin 13, enable) → bottom −, and <b>c36</b> (pin 15, reset) → bottom − (jumpers over the chip).",
 "Clock: jumper from <b>g10</b> (555 pin 3) to <b>c37</b> (4017 pin 14).",
 "10 LEDs in columns <b>46–55</b>: <b>long leg in row c</b>, <b>short leg in the top − rail</b>. Jumpers from the outputs to the LEDs' row a: Q0 <b>h37</b>→a46, Q1 <b>h36</b>→a47, Q2 <b>h38</b>→a48, Q3 <b>h41</b>→a49, Q4 <b>b41</b>→a50, Q5 <b>h35</b>→a51, Q6 <b>h39</b>→a52, Q7 <b>h40</b>→a53, Q8 <b>b42</b>→a54, Q9 <b>b40</b>→a55.",
 "Shared resistor: <b>470 Ω</b> from the top <b>−</b> rail to the bottom <b>−</b> rail (column 57).",
 "Connect the battery: red → top +, black → <b>bottom −</b>. The light runs from Q0 to Q9."
])
G['p10']=dict(how=[
 "The volume pot is a <b>voltage divider</b>: it sends a chosen fraction of the input signal to the LM386's + input (pin 3).",
 "The LM386 amplifies it 20× and drives the speaker with its <b>push-pull</b> output (pin 5). That output sits at 4.5 V and swings up and down around it.",
 "The <b>220 µF</b> blocks that steady 4.5 V and passes only the music to the speaker (the coupling trick). The <b>10 Ω + 47 nF</b> (Zobel) stops high-frequency oscillation, and the <b>100 µF</b> is a local energy reserve for loud notes."],
 steps=[
 "Battery disconnected. Link the rails (top + ↔ bottom +, top − ↔ bottom −). <b>LM386</b> across the gap, notch left, columns <b>30–33</b> (pins 1–4 bottom, 8–5 top).",
 "<b>j33</b> (pin 4) → bottom −. <b>j31</b> (pin 2) → bottom −. <b>a32</b> (pin 6) → top +.",
 "<b>100 µF</b> across the top rails, near the chip (column 27): long leg in <b>+</b>, stripe in <b>−</b>.",
 "Volume trimmer (10 kΩ) in <b>a20 a21 a22</b>. Jumper <b>b22</b> → top −. Jumper from <b>c21</b> (wiper) to <b>h32</b> (pin 3).",
 "Output: <b>220 µF</b> long leg in <b>a33</b> (pin 5), stripe leg in <b>a40</b>. Speaker red wire → <b>b40</b>, black wire → top −.",
 "Zobel: <b>10 Ω</b> from <b>c33</b> to <b>c45</b>, then <b>47 nF</b> from <b>b45</b> to the top −.",
 "Input: audio jack tip → <b>b20</b> (trimmer's left leg), sleeve → top −.",
 "Connect the battery with the trimmer at minimum, then turn it up slowly. Variant: <b>10 µF</b> between pins 1 (+) and 8 for ×200 gain."
])
G['p11']=dict(how=[
 "<b>Active buzzer:</b> it contains its own oscillator, so steady DC is enough. The button simply turns its power on.",
 "<b>Passive buzzer:</b> it is just a membrane that flexes when the voltage changes. It needs a square wave. The 555 makes one (same circuit as the blinker, but with a <b>47 nF</b> capacitor, so it oscillates ~1,000 times faster: an audible tone).",
 "The <b>10 µF</b> in series lets the wave through but blocks the DC, so the buzzer only sees the back-and-forth part."],
 steps=[
 "<b>Active (module GT1143):</b> SD80A power module at the left end, set to 5 V, switched off.",
 "Button across the gap at columns <b>8–10</b>, jumper top + → <b>a8</b>. Module <b>+</b> → top +, <b>−</b> → top −, <b>S</b> → <b>j10</b> (button's other side).",
 "Switch the power on and press: beep!",
 "<b>Passive (with the 555):</b> remove the power module and buzzer module. Build project 8's 555 circuit (same holes), but with <b>C = 47 nF</b> in <b>i21</b>, and R2 = the <b>47 kΩ trimmer</b> plus a 1 kΩ in series.",
 "Output: <b>10 µF</b> long leg in <b>h22</b> (pin 3), other leg in <b>h28</b>. Passive buzzer from <b>g28</b> to <b>g31</b>, jumper <b>j31</b> → bottom −.",
 "Connect the 9 V battery (red → top +, black → top −). Turn the trimmer to change the pitch."
])
G['p12']=dict(how=[
 "The two displays share the same 8 segment wires, so the Arduino can't light them both with different numbers at the same moment. Instead it shows display 1 for 4 ms, then display 2 for 4 ms, again and again. Your eye blends it into two steady numbers: <b>multiplexing</b>.",
 "Each display's COM (the shared cathode) goes to ground through its own <b>BC547</b>. The Arduino turns one transistor on at a time (D10 or D11). The transistors carry the whole digit's current (up to 8 × 9 mA), which a single Arduino pin couldn't.",
 "When you press the button (D12, internal pull-up so it reads LOW when pressed), the code picks random numbers faster at first, then slower, until it stops: like a real die rolling to a stop."],
 steps=[
 "USB <b>unplugged</b>. Link the − rails (top ↔ bottom). Arduino <b>GND</b> → bottom <b>−</b> rail.",
 "Display 1 across the gap, decimal point bottom-right, columns <b>20–24</b> (pins 1–5 bottom row left→right, pins 10–6 top row left→right). Display 2 the same way in columns <b>30–34</b>.",
 "Link the matching segment pins of the two displays: top <b>a20→a30, b21→b31, a23→a33, b24→b34</b>; bottom <b>j20→j30, i21→i31, j23→j33, i24→i34</b>. <b>Not</b> columns 22/32 (COM).",
 "Top-half segments (a, b, f, g): Arduino wire → row a, <b>330 Ω</b> in row b, jumper from row c to the display pin. D2→<b>a2</b>, 330 Ω <b>b2→b5</b>, <b>c5→d23</b> (a). D3→<b>a6</b>, <b>b6→b9</b>, <b>c9→d24</b> (b). D7→<b>a10</b>, <b>b10→b13</b>, <b>c13→d21</b> (f). D8→<b>a14</b>, <b>b14→b17</b>, <b>c17→d20</b> (g).",
 "Bottom-half segments (e, d, c, dp): D6→<b>j2</b>, 330 Ω <b>i2→i5</b>, <b>h5→h20</b> (e). D5→<b>j6</b>, <b>i6→i9</b>, <b>h9→h21</b> (d). D4→<b>j10</b>, <b>i10→i13</b>, <b>h13→h23</b> (c). D9→<b>j14</b>, <b>i14→i17</b>, <b>h17→h24</b> (dp).",
 "Transistors (flat side facing you, C B E): #1 in <b>c45 c46 c47</b>, #2 in <b>c50 c51 c52</b>. Emitters: <b>a47</b> and <b>a52</b> → top − rail.",
 "COM: <b>i22</b> (display 1 pin 3) → <b>e45</b> (collector #1). <b>i32</b> (display 2 pin 3) → <b>e50</b> (collector #2).",
 "Bases: Arduino <b>D10</b> → <b>a40</b>, 1 kΩ <b>b40→b46</b>. <b>D11</b> → <b>a42</b>, 1 kΩ <b>d42→d51</b>.",
 "Button across the gap at columns <b>56–58</b>: Arduino <b>D12</b> → <b>a56</b>, jumper <b>j58</b> → bottom −. Plug in USB, upload the code and press!"
])
G['rl1']=dict(how=[
 "The <b>TP4056</b> takes 5 V from USB and charges the cell in two phases. First <b>constant current</b> (1 A) while the cell voltage rises, then <b>constant voltage</b> (exactly 4.2 V) while the current fades. It stops at about 100 mA.",
 "The <b>BMS</b> sits between the cell and everything else. It contains a tiny chip and two MOSFET switches that disconnect the cell if it's over-charged, over-discharged (below ~2.5 V) or short-circuited.",
 "The charger and the load both connect to the BMS's <b>P+ / P−</b> side, so they're always protected. The cell itself only touches <b>B+ / B−</b>."],
 steps=[
 "Work with <b>no cell in the holder</b> and USB unplugged.",
 "Solder the holder's <b>red</b> wire to BMS <b>B+</b> and the <b>black</b> wire to BMS <b>B−</b>.",
 "Solder two wires from the charger's battery pads (<b>B+ / B−</b>, sometimes <b>BAT+ / BAT−</b>) to BMS <b>P+ / P−</b>.",
 "Solder your load (switch + LED with 100 Ω, or a 5 V boost module) to <b>P+ / P−</b> too.",
 "Check with a multimeter: no short between P+ and P−, and the polarity is correct everywhere.",
 "Insert the 18650 cell, <b>+ end</b> to the holder's + mark. Check with the meter: ~3–4 V on P+/P−.",
 "Plug in USB: red LED = charging, blue LED = full. Feel the chip: warm is normal, too hot to touch means unplug."])
G['rl2']=dict(how=[
 "The <b>10 kΩ + LDR</b> divider gives a voltage that rises as it gets darker (the LDR's resistance shoots up). The trimmer gives an adjustable <b>threshold</b> voltage.",
 "The <b>LM358</b> compares them. Sensor above threshold means dark, so its output jumps HIGH. The <b>1 MΩ</b> feeds a little of the output back to the + input (<b>hysteresis</b>), so once it switches it stays switched, and the lamp doesn't flicker at dusk.",
 "The HIGH output drives the <b>BC547</b> through 1 kΩ, the transistor powers the <b>relay coil</b>, and the relay's contact closes the separate <b>12 V lamp</b> circuit. The 1N4007 protects the transistor from the coil's switch-off spike."],
 steps=[
 "12 V adapter <b>unplugged</b>. Screw two wires into the <b>PCM10F</b>: <b>+</b> → top + rail, <b>−</b> → top − rail. Link top and bottom rails (+↔+, −↔−).",
 "Sensor: <b>10 kΩ</b> from the top + rail to <b>a10</b>. <b>LDR</b> from <b>c10</b> to the top − rail.",
 "<b>LM358</b> across the gap, notch left, columns <b>20–23</b>: pin 1 (out) bottom col 20, 2 (−in) col 21, 3 (+in) col 22, 4 (GND) col 23. Pin 8 (+) top col 20.",
 "<b>d20</b> (pin 8) → top +. <b>j23</b> (pin 4) → bottom −. <b>100 nF</b> from <b>b20</b> to the top − rail.",
 "Jumper from <b>e10</b> (sensor) to <b>g22</b> (pin 3).",
 "Threshold trimmer (10 kΩ) in <b>a12 a13 a14</b>: <b>b12</b> → top +, <b>b14</b> → top −, wiper <b>c13</b> → <b>h21</b> (pin 2).",
 "<b>1 MΩ</b> from <b>i20</b> (pin 1) to <b>i22</b> (pin 3).",
 "BC547 in <b>g30 g31 g32</b> (C B E). <b>1 kΩ</b> from <b>h20</b> (pin 1) to <b>h31</b> (base). Jumper <b>j32</b> (E) → bottom −.",
 "Relay (12 V) coil: one wire to the bottom + rail, the other to <b>i30</b> (collector). <b>1N4007</b>: plain end in <b>j30</b>, <b>stripe</b> in the bottom + rail.",
 "Lamp circuit: relay <b>COM</b> → top + rail, <b>NO</b> → bulb socket terminal 1, socket terminal 2 → top − rail.",
 "Plug in the 12 V adapter. Cover the LDR with your hand and turn the trimmer until you hear the <i>click</i>. Uncover: the lamp goes off."
])
