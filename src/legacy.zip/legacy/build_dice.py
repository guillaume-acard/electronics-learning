import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))) if os.path.basename(os.path.dirname(os.path.abspath(__file__))) in ('generators','legacy') else os.path.dirname(os.path.abspath(__file__)))
from paths import SRC, PAGES, SITE
import json,re
from gen_dice import js_layouts,STEPS,HOW
INFO={
'p13':dict(num=13,title='Dice without Arduino: LED dots',menu='Dice: LED dots',tag='No microcontroller',
 intro='A real dice face with 7 LEDs, made only of standard parts: a <b>555</b> clock, a <b>CD4017</b> counter, a few <b>diodes</b> and <b>transistors</b>. Hold the button: the dots change ~1,500 times a second. Let go: it freezes on a random face.',
 parts=['NE555 + CD4017','11 × 1N4148 diodes','4 × BC547','7 LEDs (same colour)','4 × 470 Ω, 5 × 10 kΩ, 1 × 1 kΩ, 1 × 47 kΩ','10 nF ceramic capacitor','Push button, 9 V battery + clip, breadboard + jumpers'],
 variants=[('Add a 100 µF capacitor from 555 pin 4 (h7 side) to −','The dice keeps rolling for about a second after you let go: more suspense!'),('Remove the reset jumper (c15 → j18)','It now counts 10 states: 4 of them show no dots at all. That\'s why the reset is needed.'),('Change the 470 Ω to 1 kΩ','Dimmer dots, and a longer battery life.'),('Build it twice','Two dice. Use two buttons, or one button for both: they still land on different faces because the two 555s run at slightly different speeds.')]),
'p14':dict(num=14,title='Dice without Arduino: 7-segment, diode matrix',menu='Dice: 7-seg matrix',tag='No microcontroller',
 intro='The same 555 + CD4017 heart, but now showing a <b>digit</b> on your <b>SC39-11SURKWA</b> display. The trick: a hand-made <b>diode matrix</b> of 27 diodes that acts like a tiny read-only memory, turning "output 3" into the segments of a "4".',
 parts=['NE555 + CD4017','27 × 1N4148 diodes','1 × SC39-11SURKWA display','7 × 2.2 kΩ, 1 × 10 kΩ, 1 × 1 kΩ, 1 × 47 kΩ','10 nF ceramic capacitor','Push button, 9 V battery + clip, breadboard + plenty of jumpers'],
 variants=[('Take out one diode of segment g','The middle bar disappears from exactly one digit: you just edited the memory!'),('Try 1 kΩ instead of 2.2 kΩ','Brighter, but the "6" (6 segments on one 4017 output) may look dimmer than the "1".'),('Add BC547 buffers (emitter followers) on the 6 outputs','Every digit gets full, even brightness: the transistors supply the current instead of the 4017.'),('Compare with project 15','Same result with 9 diodes instead of 27. Decoders exist for a reason!')]),
'p15':dict(num=15,title='Dice without Arduino: 7-segment, decoder chip',menu='Dice: 7-seg decoder',tag='No microcontroller',
 intro='The smart version: the 6 outputs of the CD4017 are turned into a 3-bit <b>binary number</b> with just <b>9 diodes</b>, and a <b>CD4511</b> decoder chip lights the right segments of your <b>SC39-11SURKWA</b>, bright and even.',
 parts=['NE555 + CD4017 + CD4511','9 × 1N4148 diodes','1 × SC39-11SURKWA display','8 × 1 kΩ (7 segments + 555), 4 × 10 kΩ, 1 × 47 kΩ','10 nF ceramic capacitor','Push button, 9 V battery + clip, breadboard + jumpers'],
 variants=[('Remove the pull-down on bit B (i27)','Bit B floats: some faces show wrong or flickering digits. Pull-downs matter for CMOS inputs!'),('Connect LT (j36) to − instead of +','"Lamp test": the display shows 8, all segments on. Handy to check the wiring.'),('Move the reset jumper from Q6 (j18) to Q9 (j21… pin 9 is b21)','Counts 10 states: the encoder only knows 1–6, so the other faces show "0" (blank bits).'),('Compare the brightness with project 14','Much brighter: the 4511 drives the segments itself.')]),
}
L=js_layouts()
s=open('circuits_body.html').read()
def section(id):
    I=INFO[id]
    how=''.join(f'<p>{p}</p>' for p in HOW[id])
    steps=''.join(f'<li><label><input type="checkbox"><span>{t}</span></label></li>' for t in STEPS[id])
    var=''.join(f'<tr><td>{a}</td><td>{b}</td></tr>' for a,b in I['variants'])
    return f'''
<section id="{id}">
  <h2><span class="num">{I['num']}</span>{I['title']}</h2>
  <p><span class="qtopic">{I['tag']}</span> {I['intro']}</p>
  <div class="controls"><button id="ddb_{id}" class="active" style="font-size:1.05rem">👆 Hold to roll</button><span class="hint">Hold, then release, just like the real button.</span></div>
  <canvas id="dd_{id}" width="800" height="300"></canvas>
  <p class="hint">Left: the 555 pulses and the CD4017 outputs (one is on). Middle: the diode {'groups' if id=='p13' else 'matrix' if id=='p14' else 'encoder'}, where the lit diodes are the ones conducting right now. Right: the result.</p>
  <div style="margin-top:12px"><h3 style="margin-top:0">🧰 You need</h3><ul>{''.join(f'<li>{x}</li>' for x in I['parts'])}</ul></div>
  <h3>💡 How it works</h3>
  <div class="howbox">{how}</div>
  <h3>🏁 Final breadboard setup</h3>
  <p class="hint" style="margin-top:-6px">This is what your board should look like when it's finished (and powered). Compare with it at the end.</p>
  <canvas id="bbF_{id}" class="bbc" width="800" height="440"></canvas>
  <h3 class="wtitle">🔌 Step-by-step wiring <span class="wprog"></span> <button class="wreset">↺ reset</button></h3>
  <p class="hint" style="margin-top:-6px">Follow the steps in order and tick each one. Always wire with the power <b>disconnected</b>, and connect the battery <b>last</b>. Steps 1–5 (clock + counter) are the same for all three dice. Column and hole numbers (a–j) follow the <a class="navlink" href="#cintro">breadboard map</a>.</p>
  <div class="bblive"><div class="bbcap">🧩 Your breadboard so far: parts appear as you tick the steps, and the <span style="color:#f59e0b">glowing outline</span> shows where the next step goes.</div><canvas id="bbS_{id}" class="bbc" width="800" height="440"></canvas></div>
  <ol class="wsteps">{steps}</ol>
  <h3>🧪 Variants to try</h3>
  <table>{var}</table>
</section>'''
for id in ['p13','p14','p15']:
    if f'<section id="{id}">' in s:
        a=s.index(f'<section id="{id}">');b=s.index('</section>',a)+10;s=s[:a]+s[b:]
k=s.index('\n<section id="rl1">')
s=s[:k]+''.join(section(i) for i in ['p13','p14','p15'])+s[k:]
# menu
if 'data-cl="p13"' not in s:
    s=s.replace('<a href="#p12" data-cl="p12"><span class="n">12</span>Digital dice</a>','<a href="#p12" data-cl="p12"><span class="n">12</span>Digital dice (Arduino)</a>'+''.join(f'<a href="#{i}" data-cl="{i}"><span class="n">{INFO[i]["num"]}</span>{INFO[i]["menu"]}</a>' for i in ['p13','p14','p15']))
s=s.replace('<a class="navlink" href="#p12">12 Digital dice</a>','<a class="navlink" href="#p12">12 Digital dice</a> · <a class="navlink" href="#p13">13–15 Dice without Arduino</a>')
s=s.replace('12 breadboard projects','15 breadboard projects')
open('circuits_body.html','w').write(s)
# JS layouts
js='\n// ===== Dice without Arduino: layouts (generated) =====\nObject.assign(BBL,'+json.dumps(L)+');\n'
c=open('circuits.js').read()
c=re.sub(r'\n// ===== Dice without Arduino: layouts \(generated\) =====\nObject\.assign\(BBL,.*?\);\n','\n',c,flags=re.S)
c=c.replace('// wire up final + live canvases',js+'// wire up final + live canvases',1)
open('circuits.js','w').write(c)
print('ok')
