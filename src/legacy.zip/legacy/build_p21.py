import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))) if os.path.basename(os.path.dirname(os.path.abspath(__file__))) in ('generators','legacy') else os.path.dirname(os.path.abspath(__file__)))
from paths import SRC, PAGES, SITE
import json,re
R,B,Y,O,U,G,P='#dc2626','#111','#ca8a04','#ea580c','#2563eb','#16a34a','#9333ea'
parts=[dict(s=1,t='wire',a='tp60',b='bp60',c=R),dict(s=1,t='wire',a='tn59',b='bn59',c=B),
 dict(s=2,t='bar',col=40,cols=['g']*6+['r']*4),
 dict(s=3,t='chip',col=10,n=18,lab='LM3914'),dict(s=3,t='wire',a='j11',b='bn11',c=B),dict(s=3,t='wire',a='j12',b='bp11',c=R),dict(s=3,t='wire',a='j18',b='bp19',c=R),dict(s=3,t='ecap',a='h12',b='bn14',lab='10µ'),
 dict(s=4,t='wire',a='j17',b='bn17',c=B),dict(s=4,t='wire',a='j13',b='bn13',c=B),dict(s=4,t='res',a='i16',b='bn16',v=2200),
 dict(s=4,t='pot',h=['h20','h21','h22']),dict(s=4,t='wire',a='g16',b='g20',c=O),dict(s=4,t='wire',a='i21',b='h15',c=P),dict(s=4,t='wire',a='j22',b='bn22',c=B),
 dict(s=5,t='npn',c='c30',b='c31',e='c32',lab='LM35'),dict(s=5,t='wire',a='a30',b='tp29',c=R),dict(s=5,t='wire',a='a32',b='tn33',c=B),dict(s=5,t='wire',a='b31',b='i14',c=Y),
 *[dict(s=6,t='wire',a=f'a{c}',b=f'tp{r}',c=R) for c,r in [(40,40),(41,41),(42,43),(43,44),(44,45),(45,46)]],
 *[dict(s=7,t='wire',a=a,b=b,c=G) for a,b in [('i10','i40'),('a10','g41'),('a11','h42'),('a12','g43'),('a13','h44'),('a14','g45')]],
 *[dict(s=8,t='wire',a=a,b=b,c=R) for a,b in [('j46','bp46'),('j47','bp47'),('j48','bp49'),('j49','bp50')]],
 *[dict(s=8,t='wire',a=a,b=b,c=U) for a,b in [('b15','b46'),('c16','c47'),('d17','d48'),('a18','a49')]],
 dict(s=9,t='batt',at=[40,30],plus='tp1',minus='tn2')]
steps=[
 "Battery disconnected. Link the rails at the right end: top <b>+</b> ↔ bottom <b>+</b> (column 60), top <b>−</b> ↔ bottom <b>−</b> (column 59).",
 "<b>DC10RG bar graph</b> across the gap in columns <b>40–49</b>, pin 1 (the marked corner) bottom-left: pins 1–10 in the bottom row (row f), pins 20–11 in the top row (row e). Segment 1 is column 40, segment 10 is column 49. <b>Quick test</b> (see the note below): 9 V battery + 1 kΩ, + on <b>a40</b> and − on <b>j40</b> should light segment 1 <b>green</b>; the other way round, <b>red</b>.",
 "<b>LM3914</b> across the gap, notch left, columns <b>10–18</b> (bottom pins 1–9: LED1, V−, V+, RLO, SIG, RHI, REF OUT, REF ADJ, MODE; top pins 18–10: LED2 … LED10). Power: <b>j11</b> (V−) → bottom −, <b>j12</b> (V+) → bottom +. Bar mode: <b>j18</b> (MODE) → bottom +. <b>10 µF</b>: + leg <b>h12</b>, − leg bottom −.",
 "Reference and range: <b>j17</b> (REF ADJ) → bottom −, <b>j13</b> (RLO = bottom of the scale) → bottom −. <b>2.2 kΩ</b> from <b>i16</b> (REF OUT) to bottom − (sets the LED current, ~7 mA). <b>10 kΩ trimmer</b> in <b>h20–h22</b>: jumper <b>g16 → g20</b> (REF OUT → one end), <b>j22</b> → bottom − (other end), wiper <b>i21 → h15</b> (RHI = top of the scale).",
 "<b>LM35DZ</b> in the top half, flat side facing you: <b>c30</b> (+Vs), <b>c31</b> (Vout), <b>c32</b> (GND). <b>a30</b> → top +, <b>a32</b> → top −. Signal: <b>b31 → i14</b> (SIG, pin 5).",
 "Green half (segments 1–6, the \"normal\" temperatures): their top pins to the + rail: <b>a40→tp40, a41→tp41, a42→tp43, a43→tp44, a44→tp45, a45→tp46</b>.",
 "Green half outputs: their bottom pins to the LM3914: <b>i10→i40</b> (LED1), <b>a10→g41</b> (LED2), <b>a11→h42</b> (LED3), <b>a12→g43</b> (LED4), <b>a13→h44</b> (LED5), <b>a14→g45</b> (LED6).",
 "Red half (segments 7–10, \"hot\"), wired the other way round so the red LED lights: bottom pins to the + rail <b>j46→bp46, j47→bp47, j48→bp49, j49→bp50</b>; top pins to the LM3914 <b>b15→b46</b> (LED7), <b>c16→c47</b> (LED8), <b>d17→d48</b> (LED9), <b>a18→a49</b> (LED10).",
 "Connect the battery. Calibrate: turn the trimmer until the number of lit segments = room temperature ÷ 5 (20 °C → 4 segments). With a multimeter: <b>0.50 V</b> on <b>h15</b> gives exactly 5 °C per segment, 0–50 °C. Pinch the LM35: the bar grows, and turns red above 30 °C."]
how=[
 "The <b>LM35</b> gives 10 mV per °C (0.22 V at 22 °C). The <b>LM3914</b> contains <b>10 comparators</b> (the \"see-saw\" from the <a class=\"navlink\" href=\"#s358\">op-amp lesson</a>) and a ladder of 10 equal resistors between RLO and RHI. Each comparator watches one rung of the ladder: if the signal is higher, it turns its LED on. More voltage = more rungs passed = a longer bar.",
 "The ladder's top (RHI) is set with the trimmer from the chip's own <b>1.25 V reference</b>. At 0.50 V, each rung is 50 mV = <b>5 °C per segment</b>, 0–50 °C. The 2.2 kΩ on REF OUT sets how much current every LED gets (about 10 × 1.25 V ÷ 2.2 kΩ, ~6–7 mA with the trimmer), so no resistor per LED is needed.",
 "<b>Water analogy:</b> a tall tank with 10 overflow holes at equal heights, each feeding a little light. The warmer it is, the higher the water rises, and the more holes spill over.",
 "The <b>DC10RG</b> has a red and a green LED in each segment, connected head-to-tail (anti-parallel): which one lights depends on which way the current flows. That's why the red half is simply wired the other way round. Not a single line of code: it all happens with comparators."]
var=[("Unplug MODE (j18)","\"Dot\" mode: only one segment lights, the one for the current temperature. Uses less battery."),
 ("Zoom on room temperatures","Raise RLO: instead of j13 → −, feed it from a second trimmer between REF OUT and −. Set RLO to 0.15 V and RHI to 0.35 V: 15–35 °C, 2 °C per segment."),
 ("Change the 2.2 kΩ to 1.2 kΩ","Brighter (~10 mA), but the LM3914 gets warm with many segments lit on 9 V."),
 ("Reverse the colours","Swap the jumpers of the red half like the green half: all green. Or flip everything: blue-ish? No: the DC10RG only has red and green!"),
 ("Use it as a battery or audio level meter","Feed SIG from a voltage divider (battery) or the Ruby's output through a diode + capacitor: a VU-meter.")]
SEC=f'''
<section id="p21">
  <h2><span class="num">21</span>Bar-graph thermometer (no Arduino)</h2>
  <p><span class="qtopic">No microcontroller</span> A 10-segment <b>DC10RG</b> bar graph that grows with the temperature: green for normal temperatures, red when it gets hot. Just three chips' worth of parts: an <b>LM35</b> sensor, an <b>LM3914</b> bar-graph driver and the bar graph itself, plus a trimmer to set the scale.</p>
  <div class="controls"><button id="bgHot" style="font-size:1.05rem">🤏 Hold to warm the sensor</button><label class="slider" style="flex:1">Trimmer (top of the scale)<input id="bgRHI" type="range" min="0.25" max="1.0" step="0.01" value="0.5" style="flex:1;width:auto"></label><label class="slider"><input type="checkbox" id="bgDot"> dot mode (MODE unplugged)</label></div>
  <canvas id="m21" width="800" height="300"></canvas>
  <p class="hint">Left: the LM35 voltage. Middle: the LM3914's ladder of 10 comparators; each one compares the signal with its own rung and switches its segment on when the signal is higher. Right: the bar graph. Move the trimmer to change the scale (0.50 V = 5 °C per segment).</p>
  <div class="howbox" style="margin-top:10px"><p>⚠️ <b>About the DC10RG wiring:</b> I couldn't read the pin drawing from Gotronic's datasheet. The steps assume each segment's red and green LEDs sit head-to-tail between its two pins (pin <i>n</i> and pin 21−<i>n</i>), green lighting when + is on the top pin. Step 2's 10-second test checks it. If it lights red instead, just swap "top" and "bottom" in steps 6–8 (or keep it and have a red-for-normal, green-for-hot bar!). Check the datasheet image on the product page too.</p></div>
  <div style="margin-top:12px"><h3 style="margin-top:0">🧰 You need</h3><ul><li>DC10RG bicolour bar graph (Gotronic 03148)</li><li>LM3914N bar-graph driver (Gotronic 21122)</li><li>LM35DZ temperature sensor (Gotronic 21071), or the LM35 module from project 20 (S, Vcc, Gnd)</li><li>10 kΩ trimmer, 2.2 kΩ resistor, 10 µF capacitor</li><li>9 V battery + clip, breadboard + plenty of jumpers</li></ul></div>
  <h3>💡 How it works</h3>
  <div class="howbox">{''.join(f'<p>{p}</p>' for p in how)}</div>
  <h3>🏁 Final breadboard setup</h3>
  <p class="hint" style="margin-top:-6px">This is what your board should look like when it's finished (and powered). Compare with it at the end.</p>
  <canvas id="bbF_p21" class="bbc" width="800" height="440"></canvas>
  <h3 class="wtitle">🔌 Step-by-step wiring <span class="wprog"></span> <button class="wreset">↺ reset</button></h3>
  <p class="hint" style="margin-top:-6px">Follow the steps in order and tick each one. Wire with the battery <b>disconnected</b>, and connect it <b>last</b>. Column and hole numbers (a–j) follow the <a class="navlink" href="#cintro">breadboard map</a>.</p>
  <div class="bblive"><div class="bbcap">🧩 Your breadboard so far: parts appear as you tick the steps, and the <span style="color:#f59e0b">glowing outline</span> shows where the next step goes.</div><canvas id="bbS_p21" class="bbc" width="800" height="440"></canvas></div>
  <ol class="wsteps">{''.join(f'<li><label><input type="checkbox"><span>{t}</span></label></li>' for t in steps)}</ol>
  <h3>🧪 Variants to try</h3>
  <table>{''.join(f'<tr><td>{a}</td><td>{b}</td></tr>' for a,b in var)}</table>
</section>'''
s=open('circuits_body.html').read()
if '<section id="p21">' in s:
    a=s.index('<section id="p21">');b=s.index('</section>',a)+10;s=s[:a]+s[b:]
k=s.index('\n<section id="rl1">');s=s[:k]+SEC+s[k:]
if 'data-cl="p21"' not in s:
    an='<a href="#p20" data-cl="p20"><span class="n">20</span>Thermometer</a>';assert an in s
    s=s.replace(an,an+'<a href="#p21" data-cl="p21"><span class="n">21</span>Bar thermometer</a>')
    an2='<a class="navlink" href="#p20">20 Thermometer</a>';assert an2 in s
    s=s.replace(an2,an2+' · <a class="navlink" href="#p21">21 Bar thermometer</a>')
s=s.replace('20 breadboard projects','21 breadboard projects')
open('circuits_body.html','w').write(s)
c=open('circuits.js').read()
js='\n// ===== p21 layout (generated) =====\nObject.assign(BBL,'+json.dumps({'p21':{'power':9,'parts':parts}})+');\n'
c=re.sub(r'\n// ===== p21 layout \(generated\) =====\nObject\.assign\(BBL,.*?\);\n','\n',c,flags=re.S)
c=c.replace('// wire up final + live canvases',js+'// wire up final + live canvases',1)
# renderer: TO-92 label + bar graph part
c=c.replace("ctx.fillText('C B E',x,y+3);break;}","ctx.fillText(p.lab||'C B E',x,y+3);break;}")
if "case 'bar':" not in c:
    bar="""  case 'bar':{const xl=HP('e'+p.col)[0]-6,xr=HP('e'+(p.col+9))[0]+6;for(let i=0;i<10;i++){pin(ctx,HP('e'+(p.col+i))[0],BB.rows.e);pin(ctx,HP('e'+(p.col+i))[0],BB.rows.f);}
    ctx.fillStyle='#1f2937';ctx.fillRect(xl,BB.rows.d+6,xr-xl,BB.rows.g-BB.rows.d-12);const n=lit?4+((performance.now()/1000)%6<3?0:2):0;
    for(let i=0;i<10;i++){const x=HP('e'+(p.col+i))[0],on=i<n,red=p.cols[i]==='r';ctx.fillStyle=on?(red?'#ef4444':'#22c55e'):(red?'#3b1d1d':'#14301f');if(on){ctx.shadowBlur=10;ctx.shadowColor=red?'#ef4444':'#22c55e';}ctx.fillRect(x-4,BB.rows.d+10,8,BB.rows.g-BB.rows.d-20);ctx.shadowBlur=0;}
    txt(ctx,'DC10RG',(xl+xr)/2,BB.rows.d+3,'#94a3b8',8);break;}
"""
    c=c.replace("  case 'npn':",bar+"  case 'npn':",1)
c=c.replace("if(p.t==='btn'||p.t==='chip'||p.t==='seg7')pts.push(HP('e'+p.col));","if(p.t==='btn'||p.t==='chip'||p.t==='seg7'||p.t==='bar')pts.push(HP('e'+p.col));")
open('circuits.js','w').write(c)
print('ok',len(steps))
