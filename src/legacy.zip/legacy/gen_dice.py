import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))) if os.path.basename(os.path.dirname(os.path.abspath(__file__))) in ('generators','legacy') else os.path.dirname(os.path.abspath(__file__)))
from paths import SRC, PAGES, SITE
import json
# ---------- shared front end: 555 + button + 4017 (holes identical in p13, p14, p15) ----------
def front():
    return [
     dict(s=1,t='wire',a='tp60',b='bp60',c='#dc2626'),dict(s=1,t='wire',a='tn59',b='bn59',c='#111'),
     dict(s=2,t='chip',col=4,n=8,lab='555'),dict(s=2,t='wire',a='d4',b='tp4',c='#dc2626'),dict(s=2,t='wire',a='j4',b='bn4',c='#111'),
     dict(s=3,t='res',a='c4',b='c5',v=1000),dict(s=3,t='res',a='b5',b='b6',v=47000),dict(s=3,t='wire',a='a6',b='i5',c='#2563eb'),dict(s=3,t='ccap',a='h5',b='bn6',lab='10n'),
     dict(s=4,t='btn',col=9),dict(s=4,t='wire',a='tp9',b='a9',c='#dc2626'),dict(s=4,t='wire',a='i11',b='i7',c='#9333ea'),dict(s=4,t='res',a='h7',b='bn8',v=10000),
     dict(s=5,t='chip',col=14,n=16,lab='CD4017'),dict(s=5,t='wire',a='d14',b='tp14',c='#dc2626'),dict(s=5,t='wire',a='j21',b='bn21',c='#111'),
     dict(s=5,t='wire',a='d17',b='tn17',c='#111'),dict(s=5,t='wire',a='c15',b='j18',c='#ea580c'),dict(s=5,t='wire',a='g6',b='c16',c='#ca8a04')]
FRONT_STEPS=[
 "Battery disconnected. Link the rails at the right end: top <b>+</b> ↔ bottom <b>+</b> (column 60), top <b>−</b> ↔ bottom <b>−</b> (column 59).",
 "<b>NE555</b> across the gap, notch left, columns <b>4–7</b> (pins 1–4 bottom row, 8–5 top row). <b>d4</b> (pin 8) → top +. <b>j4</b> (pin 1) → bottom −.",
 "Fast clock parts: <b>1 kΩ</b> c4→c5 (pin 8→7), <b>47 kΩ</b> b5→b6 (pin 7→6), jumper <b>a6 → i5</b> (pin 6 → pin 2), <b>10 nF</b> from <b>h5</b> (pin 2) to the bottom − rail. That's about 1,500 pulses per second.",
 "Roll button across the gap at columns <b>9–11</b>. Jumper top + → <b>a9</b>. Jumper <b>i11 → i7</b> (555 pin 4, reset). <b>10 kΩ</b> from <b>h7</b> to the bottom − rail, so the 555 only runs while you press.",
 "<b>CD4017</b> across the gap, notch left, columns <b>14–21</b> (pins 1–8 bottom, 16–9 top). <b>d14</b> (pin 16) → top +, <b>j21</b> (pin 8) → bottom −, <b>d17</b> (pin 13, enable) → top −. Count to 6: jumper <b>c15</b> (pin 15, reset) → <b>j18</b> (pin 5 = Q6). Clock: jumper <b>g6</b> (555 pin 3) → <b>c16</b> (pin 14)."]
# 4017 output holes: Q0 col16 bottom, Q1 col15 b, Q2 col17 b, Q3 col20 b, Q4 col20 top, Q5 col14 b
FRONT_HOW="The <b>555</b> runs only while the button is pressed (its reset pin 4 is pulled up by the button and held down by the 10 kΩ otherwise), producing ~1,500 pulses per second. The <b>CD4017</b> moves its single \"on\" output one step per pulse: Q0 → Q1 → … → Q5, and when it reaches Q6 that output resets it to Q0, so it cycles through exactly <b>6 states</b>. Nobody can stop it on purpose at that speed, so when you release the button it freezes on a random state."
def batt(s): return dict(s=s,t='batt',at=[40,30],plus='tp1',minus='tn2')
W={'R':'#dc2626','B':'#111','Y':'#ca8a04','O':'#ea580c','U':'#2563eb','G':'#16a34a','P':'#9333ea'}
DIODE_COLS=['#16a34a','#0ea5e9','#a855f7','#f97316','#eab308','#14b8a6','#ec4899']

# ---------- p13: LED-face dice ----------
p13=front()+[
 dict(s=6,t='diode',a='g16',b='f24'),dict(s=6,t='diode',a='g17',b='g24'),dict(s=6,t='diode',a='a20',b='h24'),
 dict(s=7,t='diode',a='g15',b='f28'),dict(s=7,t='diode',a='h17',b='g28'),dict(s=7,t='diode',a='g20',b='h28'),dict(s=7,t='wire',a='i28',b='i29',c=W['Y']),dict(s=7,t='diode',a='b20',b='f29'),dict(s=7,t='diode',a='g14',b='g29'),
 dict(s=8,t='diode',a='h20',b='f33'),dict(s=8,t='diode',a='c20',b='g33'),dict(s=8,t='diode',a='h14',b='h33'),dict(s=8,t='wire',a='i14',b='f37',c=W['P']),
 dict(s=9,t='npn',c='c23',b='c24',e='c25'),dict(s=9,t='npn',c='c28',b='c29',e='c30'),dict(s=9,t='npn',c='c32',b='c33',e='c34'),dict(s=9,t='npn',c='c36',b='c37',e='c38'),
 dict(s=9,t='wire',a='a25',b='tn25',c=W['B']),dict(s=9,t='wire',a='a30',b='tn30',c=W['B']),dict(s=9,t='wire',a='a34',b='tn34',c=W['B']),dict(s=9,t='wire',a='a38',b='tn38',c=W['B']),
 dict(s=9,t='res',a='i24',b='d24',v=10000),dict(s=9,t='res',a='j29',b='d29',v=10000),dict(s=9,t='res',a='i33',b='d33',v=10000),dict(s=9,t='res',a='i37',b='d37',v=10000),
 dict(s=10,t='res',a='tp45',b='a45',v=470),dict(s=10,t='res',a='tp46',b='a46',v=470),dict(s=10,t='res',a='tp48',b='a48',v=470),dict(s=10,t='res',a='tp50',b='a50',v=470),
]
# LEDs straddle the gap: anode e, cathode f
face={45:'A',46:'B',47:'B',48:'C',49:'C',50:'D',51:'D'}
for c,g in face.items(): p13.append(dict(s=10,t='led',a=f'e{c}',b=f'f{c}',grp=g))
p13+= [dict(s=10,t='wire',a='j46',b='a47',c=W['Y']),dict(s=10,t='wire',a='j48',b='a49',c=W['Y']),dict(s=10,t='wire',a='j50',b='a51',c=W['Y']),
 dict(s=10,t='wire',a='j45',b='b23',c=W['O']),dict(s=10,t='wire',a='j47',b='b28',c=W['O']),dict(s=10,t='wire',a='j49',b='b32',c=W['O']),dict(s=10,t='wire',a='j51',b='b36',c=W['O']),batt(11)]
p13_steps=FRONT_STEPS+[
 "Diodes for the <b>centre dot</b> (faces 1, 3, 5). <b>1N4148</b>, stripe on the second hole: <b>g16→f24</b> (Q0), <b>g17→g24</b> (Q2), <b>a20→h24</b> (Q4). Column 24 (bottom) is now the \"centre\" line.",
 "Diodes for the <b>diagonal ↘</b> (faces 2–6): <b>g15→f28</b> (Q1), <b>h17→g28</b> (Q2), <b>g20→h28</b> (Q3), jumper <b>i28→i29</b>, <b>b20→f29</b> (Q4), <b>g14→g29</b> (Q5).",
 "Diodes for the <b>diagonal ↙</b> (faces 4, 5, 6): <b>h20→f33</b> (Q3), <b>c20→g33</b> (Q4), <b>h14→h33</b> (Q5). <b>Middle pair</b> (face 6 only) needs no diode: jumper <b>i14 → f37</b> (Q5).",
 "4 × BC547 (flat side facing you, C B E) in the top half: <b>c23–c25</b>, <b>c28–c30</b>, <b>c32–c34</b>, <b>c36–c38</b>. Emitters <b>a25, a30, a34, a38</b> → top −. Base resistors <b>10 kΩ</b>: <b>i24→d24</b>, <b>j29→d29</b>, <b>i33→d33</b>, <b>i37→d37</b> (bottom line → top base, across the gap).",
 "7 LEDs across the gap (long leg row e, short leg row f) in columns <b>45–51</b>: 45 centre, 46 top-left, 47 bottom-right, 48 top-right, 49 bottom-left, 50 middle-left, 51 middle-right. <b>470 Ω</b> from top + to <b>a45, a46, a48, a50</b>. Series jumpers <b>j46→a47, j48→a49, j50→a51</b>. To the collectors: <b>j45→b23, j47→b28, j49→b32, j51→b36</b>.",
 "Connect the battery (red → top +, black → top −). Hold the button, release: read the dice! For a real dice face, solder the 7 LEDs on a small stripboard in the 3 × 3 pattern."]
p13_how=[FRONT_HOW,
 "A dice face only ever uses <b>4 groups</b> of dots: the centre (faces 1, 3, 5), one diagonal pair (2–6), the other diagonal pair (4, 5, 6) and the middle pair (6). Each group is an <b>OR</b>: it must light if <i>any</i> of its outputs is on.",
 "That's what the <b>diodes</b> do: several outputs feed one line through one-way valves, so an active output lights the group without pushing current back into the other (inactive) outputs. This is a tiny <b>diode logic</b> circuit.",
 "The 4017 can only supply a few mA, so each group drives a <b>BC547</b> through 10 kΩ, and the transistor switches its LEDs (pairs in series) with a 470 Ω resistor: ≈ 10–15 mA, nice and bright."]

# ---------- p14: 7-seg, diode matrix ----------
SEG_FOR={0:'bc',1:'abdeg',2:'abcdg',3:'bcfg',4:'acdfg',5:'acdefg'}  # Qn shows digit n+1
OUT_HOLES={0:['g16','h16','i16','j16'],1:['g15','h15','i15','b23','c23','d23','e23'],2:['g17','h17','i17','b25','c25','d25','e25'],
           3:['g20','h20','i20','j20'],4:['a20','b20','c20','f26','g26','h26','i26'],5:['g14','h14','i14','b27','c27','d27','e27']}
EXT=[('j15','a23'),('j17','a25'),('d20','j26'),('j14','a27')]
BUS={'a':['f30','g30','h30','i30'],'b':['f32','g32','h32','i32'],'c':['f34','g34','h34','i34','f35','g35','h35'],'d':['f37','g37','h37','i37'],
     'e':['f39','g39','h39'],'f':['f41','g41','h41','i41'],'g':['f43','g43','h43','i43','f44','g44','h44']}
BUS_EXT=[('j34','j35'),('j43','j44')]
RES={'a':('j30','c55'),'b':('j32','b56'),'c':('i35','h55'),'d':('j37','i53'),'e':('j39','g52'),'f':('j41','c53'),'g':('i44','b52')}
p14=front()+[dict(s=6,t='wire',a=a,b=b,c=W['P']) for a,b in EXT]+[dict(s=6,t='wire',a=a,b=b,c=W['Y']) for a,b in BUS_EXT]
oi={k:0 for k in OUT_HOLES};bi={k:0 for k in BUS};dlist={}
segstep={'a':7,'b':7,'c':8,'d':8,'e':9,'f':9,'g':9}
for seg in 'abcdefg':
    for q in range(6):
        if seg in SEG_FOR[q]:
            a=OUT_HOLES[q][oi[q]];oi[q]+=1;b=BUS[seg][bi[seg]];bi[seg]+=1
            p14.append(dict(s=segstep[seg],t='diode',a=a,b=b));dlist.setdefault(seg,[]).append((q,a,b))
p14+=[dict(s=10,t='seg7',col=52,show='DYN'),dict(s=10,t='wire',a='j54',b='bn54',c=W['B'])]
p14+=[dict(s=11,t='res',a=a,b=b,v=2200) for a,b in RES.values()]+[batt(12)]
def dtxt(seg): return ', '.join(f"Q{q} <b>{a}→{b}</b>" for q,a,b in dlist[seg])
p14_steps=FRONT_STEPS+[
 "Extend the busy outputs with jumpers (each output then has up to 7 holes): <b>j15→a23</b> (Q1), <b>j17→a25</b> (Q2), <b>d20→j26</b> (Q4), <b>j14→a27</b> (Q5). Join the two-column segment lines: <b>j34→j35</b> (c) and <b>j43→j44</b> (g).",
 "Segment lines are bottom columns: a = 30, b = 32, c = 34+35, d = 37, e = 39, f = 41, g = 43+44. Diodes (1N4148, stripe on the segment-line side) for <b>a</b>: "+dtxt('a')+". For <b>b</b>: "+dtxt('b')+".",
 "Diodes for <b>c</b>: "+dtxt('c')+". For <b>d</b>: "+dtxt('d')+".",
 "Diodes for <b>e</b>: "+dtxt('e')+". For <b>f</b>: "+dtxt('f')+". For <b>g</b>: "+dtxt('g')+". That's all 27!",
 "Display (SC39-11SURKWA) across the gap in columns <b>52–56</b> (pins 1–5 bottom: e d COM c dp; pins 10–6 top: g f COM a b). <b>j54</b> (COM) → bottom −.",
 "Segment resistors <b>2.2 kΩ</b> from each line to its display pin: a <b>j30→c55</b>, b <b>j32→b56</b>, c <b>i35→h55</b>, d <b>j37→i53</b>, e <b>j39→g52</b>, f <b>j41→c53</b>, g <b>i44→b52</b>.",
 "Connect the battery. Hold the button and release: a number from 1 to 6."]
p14_how=[FRONT_HOW,
 "Each output must light a different set of segments: Q0 → \"1\" (b, c), Q1 → \"2\" (a, b, d, e, g), and so on up to Q5 → \"6\". The <b>diode matrix</b> is a hand-built lookup table, or <b>ROM</b> (read-only memory). Each diode says \"when this output is on, light this segment\".",
 "Every segment line collects diodes from all the outputs that need it (that's an OR again), then goes through a 2.2 kΩ resistor to the display. Count them: 2 + 5 + 5 + 4 + 5 + 6 = <b>27 diodes</b>.",
 "The 4017 has to light up to 6 segments from one output, so each segment gets only ~2–3 mA: it works, but it's a bit dim. That's the price of the simple approach. Project 15 does the same job with only 9 diodes."]

# ---------- p15: 7-seg, 9-diode BCD encoder + CD4511 ----------
p15=front()+[
 dict(s=6,t='diode',a='g16',b='f24'),dict(s=6,t='diode',a='g17',b='g24'),dict(s=6,t='diode',a='a20',b='h24'),
 dict(s=6,t='diode',a='g15',b='f27'),dict(s=6,t='diode',a='h17',b='g27'),dict(s=6,t='diode',a='g14',b='h27'),
 dict(s=6,t='diode',a='g20',b='f30'),dict(s=6,t='diode',a='b20',b='g30'),dict(s=6,t='diode',a='h14',b='h30'),
 dict(s=7,t='res',a='i24',b='bn24',v=10000),dict(s=7,t='res',a='i27',b='bn27',v=10000),dict(s=7,t='res',a='i30',b='bn30',v=10000),
 dict(s=8,t='chip',col=34,n=16,lab='CD4511'),dict(s=8,t='wire',a='d34',b='tp34',c=W['R']),dict(s=8,t='wire',a='j41',b='bn41',c=W['B']),
 dict(s=8,t='wire',a='j36',b='bp36',c=W['R']),dict(s=8,t='wire',a='j37',b='bp37',c=W['R']),dict(s=8,t='wire',a='j38',b='bn38',c=W['B']),dict(s=8,t='wire',a='j39',b='bn39',c=W['B']),
 dict(s=9,t='wire',a='j24',b='i40',c=W['G']),dict(s=9,t='wire',a='j27',b='i34',c=W['U']),dict(s=9,t='wire',a='j30',b='i35',c=W['P']),
 dict(s=10,t='seg7',col=50,show='DYN'),dict(s=10,t='wire',a='j52',b='bn52',c=W['B']),
]+[dict(s=11,t='res',a=a,b=b,v=1000) for a,b in [('c37','c53'),('b38','b54'),('d39','h53'),('c40','i51'),('b41','g50'),('c35','c51'),('b36','b50')]]+[batt(12)]
p15_steps=FRONT_STEPS+[
 "The 9-diode <b>encoder</b> (1N4148, stripe on the second hole). Bit <b>A</b> (=1) line, bottom col 24: <b>g16→f24</b> (Q0), <b>g17→g24</b> (Q2), <b>a20→h24</b> (Q4). Bit <b>B</b> (=2), col 27: <b>g15→f27</b> (Q1), <b>h17→g27</b> (Q2), <b>g14→h27</b> (Q5). Bit <b>C</b> (=4), col 30: <b>g20→f30</b> (Q3), <b>b20→g30</b> (Q4), <b>h14→h30</b> (Q5).",
 "Pull-downs, so a bit reads 0 when no diode drives it: <b>10 kΩ</b> from <b>i24</b>, <b>i27</b> and <b>i30</b> to the bottom − rail.",
 "<b>CD4511</b> across the gap, notch left, columns <b>34–41</b> (pins 1–8 bottom: B C LT BI LE D A VSS; pins 16–9 top: VDD f g a b c d e). <b>d34</b> (VDD) → top +, <b>j41</b> (VSS) → bottom −, <b>j36</b> (LT) and <b>j37</b> (BI) → bottom +, <b>j38</b> (LE) and <b>j39</b> (D) → bottom −.",
 "Bits into the decoder: <b>j24 → i40</b> (A), <b>j27 → i34</b> (B), <b>j30 → i35</b> (C).",
 "Display across the gap, columns <b>50–54</b> (bottom: e d COM c dp, top: g f COM a b). <b>j52</b> (COM) → bottom −.",
 "Segment resistors <b>1 kΩ</b> (bend the legs, they're long): a <b>c37→c53</b>, b <b>b38→b54</b>, c <b>d39→h53</b>, d <b>c40→i51</b>, e <b>b41→g50</b>, f <b>c35→c51</b>, g <b>b36→b50</b>.",
 "Connect the battery. Hold the button and release: a bright number from 1 to 6."]
p15_how=[FRONT_HOW,
 "Instead of 27 diodes, we turn the 6 outputs into a <b>binary number</b> (BCD) with only 9 diodes: bit A (1) is on for 1, 3, 5; bit B (2) for 2, 3, 6; bit C (4) for 4, 5, 6. For example Q4 (\"5\") lights A and C: 1 + 4 = 5. The 10 kΩ pull-downs make a bit read 0 when no diode is pushing it up.",
 "The <b>CD4511</b> decoder (see <a class=\"navlink\" href=\"#parts\">Using real parts</a>) reads that 4-bit number and drives the right segments itself, with plenty of current: much brighter than project 14.",
 "Why not a ready-made counter that counts 1–6 in binary? The ideal chip (CD4510, a presettable BCD counter) isn't sold at Gotronic, and the CD4518 can only reset to 0. Using the 4017 + a diode encoder is a neat workaround with parts you already have."]

def js_layouts():
    def fix(lst):
        out=[]
        for p in lst:
            q=dict(p)
            out.append(q)
        return out
    return {'p13':{'power':11,'dice':'face','parts':fix(p13)},'p14':{'power':12,'dice':'seg','parts':fix(p14)},'p15':{'power':12,'dice':'seg','parts':fix(p15)}}
STEPS={'p13':p13_steps,'p14':p14_steps,'p15':p15_steps}
HOW={'p13':p13_how,'p14':p14_how,'p15':p15_how}
if __name__=='__main__':
    print({k:len(v) for k,v in STEPS.items()}, len(p14), sum(1 for p in p14 if p['t']=='diode'))
