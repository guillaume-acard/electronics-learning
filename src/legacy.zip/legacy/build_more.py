import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))) if os.path.basename(os.path.dirname(os.path.abspath(__file__))) in ('generators','legacy') else os.path.dirname(os.path.abspath(__file__)))
from paths import SRC, PAGES, SITE
import json,re
from gen_more import LAY,STEPS,HOW
SEL=lambda id,lab,opts,v: f'<label class="slider">{lab} <select id="{id}" style="font:inherit;padding:6px;border-radius:6px;background:#2a3650;color:#e2e8f0;border:1px solid #2a3650">'+''.join(f'<option value="{a}"{" selected" if a==v else ""}>{b}</option>' for a,b in opts)+'</select></label>'
CAPS=[('1','1 µF'),('10','10 µF'),('100','100 µF')]
INFO={
'p16':dict(num=16,title='Two-LED flip-flop (no chip!)',menu='LED flip-flop',tag='Transistors only',
 intro='Two LEDs that blink in turn, made from just <b>2 transistors, 2 capacitors and 4 resistors</b>. No chip at all: this is the circuit hidden inside the 555 and every blinker, built from loose parts so you can see how an <b>oscillator</b> works.',
 demo=SEL('m16c1','Capacitor C1',CAPS,'10')+SEL('m16c2','Capacitor C2',CAPS,'10'),
 hint='Left: the circuit, with each capacitor\'s charge. Right: the voltage on each transistor\'s base. It dives below 0 V when the other transistor switches on, then climbs back up through 47 kΩ; at 0.6 V the transistor switches on and the LEDs swap. Try different C1 and C2.',
 parts=['2 × BC547','2 × 10 µF electrolytic capacitors','2 × 47 kΩ, 2 × 470 Ω','2 LEDs (one red, one green)','9 V battery + clip, breadboard + jumpers'],
 variants=[('Change both 10 µF to 100 µF','10 × slower: about one swap every 3 seconds.'),('Use 1 µF for one and 100 µF for the other','Uneven blinking: one LED flashes, the other stays on long. The time on each side depends on ITS capacitor.'),('Use 1 µF for both','~15 swaps per second: both LEDs seem on at the same time. That\'s persistence of vision, the trick behind multiplexed displays (project 12).'),('Replace an LED with a speaker + 100 nF capacitors','Much faster swaps (~150 Hz): you hear a buzzy tone.')]),
'p17':dict(num=17,title='Police siren (two 555s)',menu='Police siren',tag='555 × 2',
 intro='The French "pin-pon": one slow 555 switches a second, fast 555 between two notes. You\'ll use the mysterious <b>pin 5 (CTRL)</b> of the 555, and hear the result on a small speaker.',
 demo='<button id="m17play">🔊 Play the siren</button><button id="m17a" class="active">Pin-pon (two-tone)</button><button id="m17b">Wail (100 µF on pin 5)</button>',
 hint='Top: the slow 555 output (9 V or 0 V). Bottom: the pitch of the fast 555. In "wail" mode the 100 µF capacitor on pin 5 makes the pitch glide instead of jumping.',
 parts=['2 × NE555','1 × 10 µF, 1 × 100 nF capacitors','2 × 1 kΩ, 1 × 47 kΩ, 2 × 10 kΩ, 1 × 470 Ω, 1 × 220 Ω','1 LED','8 Ω speaker (HP508)','9 V battery + clip, breadboard + jumpers'],
 variants=[('Add 100 µF from b23 (pin 5 of 555 #2) to −','American "wail": the pitch glides up and down.'),('Replace the 47 kΩ (b5→b6) with 4.7 kΩ','The siren switches ~10 times per second: a "space laser" warble.'),('Replace the 100 nF (h21) with 47 nF','Both notes go up about an octave.'),('Remove the jumper h6 → a14','Just one steady beep: 555 #1 no longer moves pin 5.')]),
'p18':dict(num=18,title='Fuzz pedal for your Ruby',menu='Fuzz pedal',tag='Guitar',
 intro='A real guitar effect: a two-transistor <b>"Fuzz Face"</b> that goes between your guitar and the <b>Ruby amp</b>. It turns clean notes into the thick, buzzy fuzz of 60s and 70s rock.',
 demo='<label class="slider" style="flex:1">Fuzz (22 µF on Q2 emitter)<input id="m18f" type="range" min="0" max="1" step="0.01" value="0.8" style="flex:1;width:auto"></label><label class="slider" style="flex:1">Bias trimmer<input id="m18b" type="range" min="0" max="1" step="0.01" value="0.5" style="flex:1;width:auto"></label><button id="m18c">🎸 Play clean</button><button id="m18p">🔥 Play with fuzz</button>',
 hint='Left: one guitar note going in (blue) and coming out (orange). Right: the "transfer curve": how the input is mapped to the output. Flat parts = clipping. Move the bias away from the middle: the clipping becomes lopsided and the sound gets thin and sputtery.',
 parts=['2 × BC547 (BC547A or BC549C also fine)','10 kΩ trimmer (bias)','33 kΩ, 100 kΩ, 1 kΩ, 470 Ω resistors','2.2 µF and 22 µF electrolytic, 10 nF ceramic capacitors','2 × 6.35 mm mono female jacks (solder 2 wires to each) + 2 guitar cables','9 V battery + clip, breadboard + jumpers'],
 variants=[('Replace the 22 µF with 2.2 µF','Less gain for the music: a milder, crunchier overdrive.'),('Add a 1 kΩ in series with the 22 µF','A "fuzz knob" halfway: use the 10 kΩ trimmer\'s twin as a real knob for the full range.'),('Turn the trimmer to each end','Too low or too high bias: a thin, "dying battery" gated sound, a style some players love.'),('Add a 47 kΩ trimmer as a volume','Output → trimmer pin 1, pin 3 → −, wiper → OUT jack: tames the level before the Ruby.')]),
'p19':dict(num=19,title='2-digit counter 00–99',menu='Counter 00–99',tag='Counting chips',
 intro='Two <b>SC39-11SURKWA</b> displays count from 00 to 99 by themselves: a 555 ticks, a <b>CD4518</b> counts in decimal and carries over to the tens, and two <b>CD4511</b> light the digits. A reset button brings it back to 00.',
 demo='<button id="m19run" class="active">⏸ Pause</button><button id="m19tick">👆 One tick</button><button id="m19rst">↺ Reset (button)</button><label class="slider">Speed<input id="m19sp" type="range" min="0.5" max="20" step="0.5" value="1.5"></label>',
 hint='The 4 outputs of each counter are worth 8, 4, 2 and 1. Watch the units\' "8" bit: when it drops (9 → 0), it ticks the tens. That\'s the carry.',
 parts=['NE555 + CD4518 + 2 × CD4511','2 × SC39-11SURKWA displays','15 × 1 kΩ (14 segments + 555), 1 × 47 kΩ, 1 × 10 kΩ','10 µF electrolytic capacitor','Push button, 9 V battery + clip (or the USB power module), breadboard + plenty of jumpers'],
 variants=[('Replace the 10 µF with 1 µF','10 times faster: a stopwatch counting tenths of seconds.'),('Remove the jumper g14 → b15','The tens never move: the units count 0–9 forever. The carry is that one wire!'),('Disconnect the 555 (h5 → h9) and clock with a button','Count people coming in: a button from + to h9 with a 10 kΩ to −. (Add a 100 nF across the button to stop "bounce" double counts.)'),('Connect LT (j21 / j37) to −','"Lamp test": both displays show 88.')]),
}
s=open('circuits_body.html').read()
def section(id):
    I=INFO[id]
    how=''.join(f'<p>{p}</p>' for p in HOW[id])
    steps=''.join(f'<li><label><input type="checkbox"><span>{t}</span></label></li>' for t in STEPS[id])
    var=''.join(f'<tr><td>{a}</td><td>{b}</td></tr>' for a,b in I['variants'])
    return f'''
<section id="{id}">
  <h2><span class="num">{I['num']}</span>{I['title']}</h2>
  <p><span class="qtopic">{I['tag']}</span> {I['intro']}</p>
  <div class="controls">{I['demo']}</div>
  <canvas id="m{id[1:]}" width="800" height="300"></canvas>
  <p class="hint">{I['hint']}</p>
  <div style="margin-top:12px"><h3 style="margin-top:0">🧰 You need</h3><ul>{''.join(f'<li>{x}</li>' for x in I['parts'])}</ul></div>
  <h3>💡 How it works</h3>
  <div class="howbox">{how}</div>
  <h3>🏁 Final breadboard setup</h3>
  <p class="hint" style="margin-top:-6px">This is what your board should look like when it's finished (and powered). Compare with it at the end.</p>
  <canvas id="bbF_{id}" class="bbc" width="800" height="440"></canvas>
  <h3 class="wtitle">🔌 Step-by-step wiring <span class="wprog"></span> <button class="wreset">↺ reset</button></h3>
  <p class="hint" style="margin-top:-6px">Follow the steps in order and tick each one. Always wire with the power <b>disconnected</b>, and connect the battery <b>last</b>. Column and hole numbers (a–j) follow the <a class="navlink" href="#cintro">breadboard map</a>.</p>
  <div class="bblive"><div class="bbcap">🧩 Your breadboard so far: parts appear as you tick the steps, and the <span style="color:#f59e0b">glowing outline</span> shows where the next step goes.</div><canvas id="bbS_{id}" class="bbc" width="800" height="440"></canvas></div>
  <ol class="wsteps">{steps}</ol>
  <h3>🧪 Variants to try</h3>
  <table>{var}</table>
</section>'''
IDS=['p16','p17','p18','p19']
for id in IDS:
    if f'<section id="{id}">' in s:
        a=s.index(f'<section id="{id}">');b=s.index('</section>',a)+10;s=s[:a]+s[b:]
k=s.index('\n<section id="rl1">')
s=s[:k]+''.join(section(i) for i in IDS)+s[k:]
if 'data-cl="p16"' not in s:
    anchor='<a href="#p15" data-cl="p15"><span class="n">15</span>Dice: 7-seg decoder</a>'
    assert anchor in s
    s=s.replace(anchor,anchor+'<h4>Next level</h4>'+''.join(f'<a href="#{i}" data-cl="{i}"><span class="n">{INFO[i]["num"]}</span>{INFO[i]["menu"]}</a>' for i in IDS))
    s=s.replace('<a class="navlink" href="#p13">13–15 Dice without Arduino</a></td></tr>','<a class="navlink" href="#p13">13–15 Dice without Arduino</a></td></tr>\n    <tr><td>Next level</td><td>'+' · '.join(f'<a class="navlink" href="#{i}">{INFO[i]["num"]} {INFO[i]["menu"]}</a>' for i in IDS)+'</td></tr>')
s=s.replace('15 breadboard projects','19 breadboard projects')
open('circuits_body.html','w').write(s)
js='\n// ===== Next-level projects: layouts (generated) =====\nObject.assign(BBL,'+json.dumps(LAY)+');\n'
c=open('circuits.js').read()
c=re.sub(r'\n// ===== Next-level projects: layouts \(generated\) =====\nObject\.assign\(BBL,.*?\);\n','\n',c,flags=re.S)
c=c.replace('// wire up final + live canvases',js+'// wire up final + live canvases',1)
# renderer tweaks: inverted blink + counting display
c=c.replace("if(p.blink)pl=lit&&(t%0.7)<0.38;","if(p.blink)pl=lit&&(((t%0.7)<0.35)!==(p.blink===2));")
c=c.replace("p.show==='DYN'?DIG7[1+Math.floor((T&&T.t||performance.now()/1000)*0.6)%6]:","p.show==='DYN'?DIG7[1+Math.floor((T&&T.t||performance.now()/1000)*0.6)%6]:p.show==='CNT'?DIG7[(p.place?Math.floor(Math.floor(performance.now()/1000*1.5)%100/10):Math.floor(performance.now()/1000*1.5)%10)]:")
open('circuits.js','w').write(c)
print('ok')
